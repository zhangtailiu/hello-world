package com.example.dmi.metadata.persistence;

import com.example.dmi.metadata.persistence.entity.ObjectDefinitionEntity;
import com.example.dmi.metadata.persistence.entity.ObjectFieldEntity;
import com.example.dmi.metadata.persistence.mapper.ObjectDefinitionMapper;
import com.example.dmi.metadata.persistence.mapper.ObjectFieldMapper;
import com.example.dmi.support.MySqlIntegrationTest;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class MetadataMapperIntegrationTest extends MySqlIntegrationTest {
    @Autowired ObjectDefinitionMapper objectMapper;
    @Autowired ObjectFieldMapper fieldMapper;

    @Test
    void persistsObjectAndField() {
        long objectId = 90001L;
        long fieldId = 90002L;
        LocalDateTime now = LocalDateTime.now();
        objectMapper.insert(new ObjectDefinitionEntity(objectId, "测试对象", null, null, now, now));
        fieldMapper.insert(new ObjectFieldEntity(fieldId, objectId, "id", "STRING", true, null, now, now));

        assertThat(objectMapper.selectById(objectId).getObjectName()).isEqualTo("测试对象");
        assertThat(fieldMapper.selectById(fieldId).getObjectId()).isEqualTo(objectId);
    }
}
