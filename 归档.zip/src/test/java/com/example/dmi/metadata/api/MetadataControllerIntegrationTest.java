package com.example.dmi.metadata.api;

import com.example.dmi.support.MySqlIntegrationTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class MetadataControllerIntegrationTest extends MySqlIntegrationTest {
    @Autowired MockMvc mockMvc;

    @Test
    void createsAndQueriesMetadata() throws Exception {
        String response = mockMvc.perform(post("/api/metadata/objects/save")
                .contentType(MediaType.APPLICATION_JSON)
                .content(validObjectJson("接口品牌")))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.success").value(true))
            .andExpect(jsonPath("$.objectId").isNumber())
            .andReturn().getResponse().getContentAsString();
        String objectId = response.replaceAll(".*\"objectId\":(\\d+).*", "$1");

        mockMvc.perform(get("/api/metadata/objects/{objectId}", objectId))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.objectName").value("接口品牌"));
        mockMvc.perform(get("/api/metadata/graph").param("objectIds", objectId))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.objects.length()").value(1));
    }

    @Test
    void returnsStructuredErrors() throws Exception {
        mockMvc.perform(post("/api/metadata/objects/save")
                .contentType(MediaType.APPLICATION_JSON)
                .content("""
                    {"objectName":"无主键","fields":[{"fieldName":"name","fieldType":"STRING","primaryKey":false}],
                     "outgoingRelations":[]}
                    """))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.code").value("INVALID_DEFINITION"));

        mockMvc.perform(get("/api/metadata/objects/-1"))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.code").value("OBJECT_NOT_FOUND"));
    }

    private String validObjectJson(String name) {
        return """
            {"objectName":"%s","fields":[{"fieldName":"id","fieldType":"STRING","primaryKey":true}],
             "outgoingRelations":[]}
            """.formatted(name);
    }
}
