package com.example.dmi.metadata.api.dto;

import java.util.List;

public record ObjectDefinitionResponse(
    Long objectId, String objectName, Long parentObjectId, String description,
    List<FieldResponse> fields,
    List<RelationResponse> outgoingRelations,
    List<RelationResponse> incomingRelations
) {}
