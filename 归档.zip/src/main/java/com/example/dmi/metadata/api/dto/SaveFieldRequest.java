package com.example.dmi.metadata.api.dto;

import com.example.dmi.metadata.model.FieldType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record SaveFieldRequest(
    Long fieldId,
    @NotBlank String fieldName,
    @NotNull FieldType fieldType,
    boolean primaryKey,
    String description
) {}
