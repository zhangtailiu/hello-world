package com.example.dmi.metadata.api.dto;

public record SaveObjectResponse(Long objectId, boolean success) {}
