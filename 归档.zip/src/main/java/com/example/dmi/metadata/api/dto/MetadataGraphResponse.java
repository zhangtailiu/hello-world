package com.example.dmi.metadata.api.dto;

import java.util.List;

public record MetadataGraphResponse(
    List<ObjectSummaryResponse> objects, List<FieldResponse> fields, List<RelationResponse> relations
) {}
