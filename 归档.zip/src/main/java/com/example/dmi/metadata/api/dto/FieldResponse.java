package com.example.dmi.metadata.api.dto;

import com.example.dmi.metadata.model.FieldType;

public record FieldResponse(
    Long fieldId, Long objectId, String fieldName, FieldType fieldType, boolean primaryKey, String description
) {}
