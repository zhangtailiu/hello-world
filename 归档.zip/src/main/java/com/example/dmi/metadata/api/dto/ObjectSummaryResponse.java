package com.example.dmi.metadata.api.dto;

public record ObjectSummaryResponse(Long objectId, String objectName, Long parentObjectId, String description) {}
