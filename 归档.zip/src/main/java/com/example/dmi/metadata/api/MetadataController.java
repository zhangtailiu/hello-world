package com.example.dmi.metadata.api;

import com.example.dmi.metadata.api.dto.MetadataGraphResponse;
import com.example.dmi.metadata.api.dto.ObjectDefinitionResponse;
import com.example.dmi.metadata.api.dto.SaveObjectRequest;
import com.example.dmi.metadata.api.dto.SaveObjectResponse;
import com.example.dmi.metadata.application.MetadataQueryService;
import com.example.dmi.metadata.application.MetadataSaveService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/metadata")
public class MetadataController {
    private final MetadataSaveService saveService;
    private final MetadataQueryService queryService;

    public MetadataController(MetadataSaveService saveService, MetadataQueryService queryService) {
        this.saveService = saveService;
        this.queryService = queryService;
    }

    @PostMapping("/objects/save")
    public SaveObjectResponse save(@Valid @RequestBody SaveObjectRequest request) {
        return saveService.save(request);
    }

    @GetMapping("/objects/{objectId}")
    public ObjectDefinitionResponse getObject(@PathVariable Long objectId) {
        return queryService.getObject(objectId);
    }

    @GetMapping("/graph")
    public MetadataGraphResponse getGraph(@RequestParam(required = false) List<Long> objectIds) {
        return queryService.getGraph(objectIds == null ? List.of() : objectIds);
    }
}
