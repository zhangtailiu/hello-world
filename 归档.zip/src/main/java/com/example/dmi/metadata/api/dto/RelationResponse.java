package com.example.dmi.metadata.api.dto;

import com.example.dmi.metadata.model.RelationType;

public record RelationResponse(
    Long relationId, String relationName, Long sourceObjectId, Long sourceFieldId,
    Long targetObjectId, Long targetFieldId, RelationType relationType, String description
) {}
