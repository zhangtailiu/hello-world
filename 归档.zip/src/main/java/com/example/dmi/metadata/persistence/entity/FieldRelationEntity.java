package com.example.dmi.metadata.persistence.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

@TableName("field_relation")
public class FieldRelationEntity {
    @TableId
    private Long relationId;
    private String relationName;
    private Long sourceFieldId;
    private Long targetObjectId;
    private Long targetFieldId;
    private String relationType;
    private String description;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public FieldRelationEntity() {}

    public FieldRelationEntity(Long relationId, String relationName, Long sourceFieldId, Long targetObjectId,
                               Long targetFieldId, String relationType, String description,
                               LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.relationId = relationId; this.relationName = relationName; this.sourceFieldId = sourceFieldId;
        this.targetObjectId = targetObjectId; this.targetFieldId = targetFieldId; this.relationType = relationType;
        this.description = description; this.createdAt = createdAt; this.updatedAt = updatedAt;
    }

    public Long getRelationId() { return relationId; }
    public void setRelationId(Long relationId) { this.relationId = relationId; }
    public String getRelationName() { return relationName; }
    public void setRelationName(String relationName) { this.relationName = relationName; }
    public Long getSourceFieldId() { return sourceFieldId; }
    public void setSourceFieldId(Long sourceFieldId) { this.sourceFieldId = sourceFieldId; }
    public Long getTargetObjectId() { return targetObjectId; }
    public void setTargetObjectId(Long targetObjectId) { this.targetObjectId = targetObjectId; }
    public Long getTargetFieldId() { return targetFieldId; }
    public void setTargetFieldId(Long targetFieldId) { this.targetFieldId = targetFieldId; }
    public String getRelationType() { return relationType; }
    public void setRelationType(String relationType) { this.relationType = relationType; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
