package com.example.dmi.metadata.application;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.dmi.common.error.ErrorCode;
import com.example.dmi.common.error.MetadataException;
import com.example.dmi.metadata.api.dto.FieldResponse;
import com.example.dmi.metadata.api.dto.MetadataGraphResponse;
import com.example.dmi.metadata.api.dto.ObjectDefinitionResponse;
import com.example.dmi.metadata.api.dto.ObjectSummaryResponse;
import com.example.dmi.metadata.api.dto.RelationResponse;
import com.example.dmi.metadata.model.FieldType;
import com.example.dmi.metadata.model.RelationType;
import com.example.dmi.metadata.persistence.entity.FieldRelationEntity;
import com.example.dmi.metadata.persistence.entity.ObjectDefinitionEntity;
import com.example.dmi.metadata.persistence.entity.ObjectFieldEntity;
import com.example.dmi.metadata.persistence.mapper.FieldRelationMapper;
import com.example.dmi.metadata.persistence.mapper.ObjectDefinitionMapper;
import com.example.dmi.metadata.persistence.mapper.ObjectFieldMapper;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class MetadataQueryService {
    private final ObjectDefinitionMapper objectMapper;
    private final ObjectFieldMapper fieldMapper;
    private final FieldRelationMapper relationMapper;

    public MetadataQueryService(ObjectDefinitionMapper objectMapper, ObjectFieldMapper fieldMapper,
                                FieldRelationMapper relationMapper) {
        this.objectMapper = objectMapper;
        this.fieldMapper = fieldMapper;
        this.relationMapper = relationMapper;
    }

    public ObjectDefinitionResponse getObject(Long objectId) {
        ObjectDefinitionEntity object = requireObject(objectId);
        Map<Long, ObjectFieldEntity> fieldsById = allFieldsById();
        List<FieldResponse> fields = fieldsById.values().stream()
            .filter(field -> field.getObjectId().equals(objectId)).map(this::fieldResponse).sorted(fieldOrder()).toList();
        List<RelationResponse> outgoing = relationMapper.selectBySourceObjectId(objectId).stream()
            .map(relation -> relationResponse(relation, fieldsById)).toList();
        List<RelationResponse> incoming = relationMapper.selectByTargetObjectId(objectId).stream()
            .map(relation -> relationResponse(relation, fieldsById)).toList();
        return new ObjectDefinitionResponse(object.getObjectId(), object.getObjectName(), object.getParentObjectId(),
            object.getDescription(), fields, outgoing, incoming);
    }

    public MetadataGraphResponse getGraph(List<Long> requestedObjectIds) {
        List<Long> objectIds = requestedObjectIds == null ? List.of() : requestedObjectIds.stream().distinct().toList();
        List<FieldRelationEntity> relations;
        Set<Long> includedObjectIds = new HashSet<>();
        Map<Long, ObjectFieldEntity> allFields = allFieldsById();

        if (objectIds.isEmpty()) {
            objectMapper.selectList(null).forEach(object -> includedObjectIds.add(object.getObjectId()));
            relations = relationMapper.selectList(Wrappers.<FieldRelationEntity>lambdaQuery()
                .orderByAsc(FieldRelationEntity::getRelationId));
        } else if (objectIds.size() == 1) {
            requireObject(objectIds.get(0));
            includedObjectIds.add(objectIds.get(0));
            relations = relationMapper.selectRelationsTouchingObject(objectIds.get(0));
            relations.forEach(relation -> {
                includedObjectIds.add(allFields.get(relation.getSourceFieldId()).getObjectId());
                includedObjectIds.add(relation.getTargetObjectId());
            });
        } else {
            objectIds.forEach(this::requireObject);
            includedObjectIds.addAll(objectIds);
            relations = relationMapper.selectRelationsWithinObjects(objectIds);
        }

        List<ObjectSummaryResponse> objects = objectMapper.selectBatchIds(includedObjectIds).stream()
            .map(this::objectResponse).sorted(Comparator.comparing(ObjectSummaryResponse::objectId)).toList();
        List<FieldResponse> fields = allFields.values().stream()
            .filter(field -> includedObjectIds.contains(field.getObjectId()))
            .map(this::fieldResponse).sorted(fieldOrder()).toList();
        List<RelationResponse> responses = relations.stream()
            .map(relation -> relationResponse(relation, allFields))
            .sorted(Comparator.comparing(RelationResponse::relationId)).toList();
        return new MetadataGraphResponse(objects, fields, responses);
    }

    private ObjectDefinitionEntity requireObject(Long objectId) {
        ObjectDefinitionEntity object = objectMapper.selectById(objectId);
        if (object == null) {
            throw new MetadataException(ErrorCode.OBJECT_NOT_FOUND, "对象不存在: " + objectId);
        }
        return object;
    }

    private Map<Long, ObjectFieldEntity> allFieldsById() {
        return fieldMapper.selectList(null).stream()
            .collect(Collectors.toMap(ObjectFieldEntity::getFieldId, Function.identity()));
    }

    private ObjectSummaryResponse objectResponse(ObjectDefinitionEntity object) {
        return new ObjectSummaryResponse(object.getObjectId(), object.getObjectName(),
            object.getParentObjectId(), object.getDescription());
    }

    private FieldResponse fieldResponse(ObjectFieldEntity field) {
        return new FieldResponse(field.getFieldId(), field.getObjectId(), field.getFieldName(),
            FieldType.valueOf(field.getFieldType()), Boolean.TRUE.equals(field.getIsPrimaryKey()), field.getDescription());
    }

    private RelationResponse relationResponse(FieldRelationEntity relation, Map<Long, ObjectFieldEntity> fieldsById) {
        ObjectFieldEntity source = fieldsById.get(relation.getSourceFieldId());
        return new RelationResponse(relation.getRelationId(), relation.getRelationName(), source.getObjectId(),
            relation.getSourceFieldId(), relation.getTargetObjectId(), relation.getTargetFieldId(),
            RelationType.valueOf(relation.getRelationType()), relation.getDescription());
    }

    private Comparator<FieldResponse> fieldOrder() {
        return Comparator.comparing(FieldResponse::fieldId);
    }
}
