package com.example.dmi.metadata.api.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;

public record SaveObjectRequest(
    Long objectId,
    @NotBlank String objectName,
    Long parentObjectId,
    String description,
    @NotEmpty List<@Valid SaveFieldRequest> fields,
    @NotNull List<@Valid SaveRelationRequest> outgoingRelations
) {}
