package com.example.dmi.metadata.api.dto;

import com.example.dmi.metadata.model.RelationType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record SaveRelationRequest(
    Long relationId,
    String relationName,
    @NotBlank String sourceFieldName,
    @NotNull Long targetObjectId,
    @NotNull Long targetFieldId,
    @NotNull RelationType relationType,
    String description
) {}
