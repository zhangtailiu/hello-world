package com.example.dmi.metadata.persistence.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

@TableName("object_field")
public class ObjectFieldEntity {
    @TableId
    private Long fieldId;
    private Long objectId;
    private String fieldName;
    private String fieldType;
    private Boolean isPrimaryKey;
    private String description;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public ObjectFieldEntity() {}

    public ObjectFieldEntity(Long fieldId, Long objectId, String fieldName, String fieldType, Boolean isPrimaryKey,
                             String description, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.fieldId = fieldId;
        this.objectId = objectId;
        this.fieldName = fieldName;
        this.fieldType = fieldType;
        this.isPrimaryKey = isPrimaryKey;
        this.description = description;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Long getFieldId() { return fieldId; }
    public void setFieldId(Long fieldId) { this.fieldId = fieldId; }
    public Long getObjectId() { return objectId; }
    public void setObjectId(Long objectId) { this.objectId = objectId; }
    public String getFieldName() { return fieldName; }
    public void setFieldName(String fieldName) { this.fieldName = fieldName; }
    public String getFieldType() { return fieldType; }
    public void setFieldType(String fieldType) { this.fieldType = fieldType; }
    public Boolean getIsPrimaryKey() { return isPrimaryKey; }
    public void setIsPrimaryKey(Boolean primaryKey) { isPrimaryKey = primaryKey; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
