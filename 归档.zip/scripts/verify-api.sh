#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:8080}"
RUN_ID="${RUN_ID:-$(date +%s)}"
brand_name="验证品牌-$RUN_ID"
product_name="验证产品-$RUN_ID"

brand_response=$(curl -fsS -X POST "$BASE_URL/api/metadata/objects/save" \
  -H 'Content-Type: application/json' \
  -d "{\"objectName\":\"$brand_name\",\"fields\":[{\"fieldName\":\"id\",\"fieldType\":\"STRING\",\"primaryKey\":true},{\"fieldName\":\"name\",\"fieldType\":\"STRING\",\"primaryKey\":false}],\"outgoingRelations\":[]}")
brand_id=$(jq -er '.objectId' <<<"$brand_response")
brand_field_id=$(curl -fsS "$BASE_URL/api/metadata/objects/$brand_id" | jq -er '.fields[] | select(.fieldName == "id") | .fieldId')

product_response=$(curl -fsS -X POST "$BASE_URL/api/metadata/objects/save" \
  -H 'Content-Type: application/json' \
  -d "{\"objectName\":\"$product_name\",\"fields\":[{\"fieldName\":\"id\",\"fieldType\":\"STRING\",\"primaryKey\":true},{\"fieldName\":\"brand_id\",\"fieldType\":\"STRING\",\"primaryKey\":false}],\"outgoingRelations\":[{\"relationName\":\"所属品牌\",\"sourceFieldName\":\"brand_id\",\"targetObjectId\":$brand_id,\"targetFieldId\":$brand_field_id,\"relationType\":\"MANY_TO_ONE\"}]}")
product_id=$(jq -er '.objectId' <<<"$product_response")

curl -fsS "$BASE_URL/api/metadata/objects/$product_id" | jq -e '.outgoingRelations | length == 1' >/dev/null
curl -fsS "$BASE_URL/api/metadata/graph?objectIds=$brand_id" | jq -e '.objects | length == 2' >/dev/null
curl -fsS "$BASE_URL/api/metadata/graph?objectIds=$brand_id,$product_id" | jq -e '.relations | length == 1' >/dev/null

brand_name_field_id=$(curl -fsS "$BASE_URL/api/metadata/objects/$brand_id" |
  jq -er '.fields[] | select(.fieldName == "name") | .fieldId')
status=$(curl -sS -o /tmp/dmi-field-reference-error.json -w '%{http_code}' -X POST \
  "$BASE_URL/api/metadata/objects/save" -H 'Content-Type: application/json' \
  -d "{\"objectId\":$brand_id,\"objectName\":\"$brand_name\",\"fields\":[{\"fieldId\":$brand_name_field_id,\"fieldName\":\"name\",\"fieldType\":\"STRING\",\"primaryKey\":true}],\"outgoingRelations\":[]}")
test "$status" = "409"
jq -e '.code == "FIELD_REFERENCED"' /tmp/dmi-field-reference-error.json >/dev/null

echo "Metadata API verification passed: brand=$brand_id product=$product_id"
