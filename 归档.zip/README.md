# DMI 元数据服务

## 能力

- `POST /api/metadata/objects/save`：无 `objectId` 时创建，有 `objectId` 时全量覆盖。
- `GET /api/metadata/objects/{objectId}`：查询单对象完整定义。
- `GET /api/metadata/graph`：查询全量元数据图。
- `GET /api/metadata/graph?objectIds=id1,id2`：按对象集合查询元数据图。

## 本地启动

```bash
docker compose up -d
mvn spring-boot:run
```

另一个终端执行：

```bash
chmod +x scripts/verify-api.sh
./scripts/verify-api.sh
```

## 自动化测试

测试使用 Testcontainers 自动启动隔离的 MySQL：

```bash
TESTCONTAINERS_RYUK_DISABLED=true DOCKER_AUTH_CONFIG='{}' mvn clean test
```

## Docker 应用镜像

本地 Java 启动不可用时：

```bash
mvn -DskipTests package
docker build -t dmi-metadata .
docker run --rm -p 8080:8080 \
  -e DB_URL='jdbc:mysql://host.docker.internal:3306/dmi?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC' \
  -e DB_USERNAME=dmi -e DB_PASSWORD=dmi dmi-metadata
```
