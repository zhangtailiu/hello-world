CREATE TABLE object_definition (
    object_id BIGINT NOT NULL PRIMARY KEY,
    object_name VARCHAR(128) NOT NULL,
    parent_object_id BIGINT NULL,
    description VARCHAR(512) NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    CONSTRAINT uk_object_definition_name UNIQUE (object_name),
    CONSTRAINT fk_object_parent FOREIGN KEY (parent_object_id) REFERENCES object_definition (object_id)
);

CREATE TABLE object_field (
    field_id BIGINT NOT NULL PRIMARY KEY,
    object_id BIGINT NOT NULL,
    field_name VARCHAR(128) NOT NULL,
    field_type VARCHAR(32) NOT NULL,
    is_primary_key BOOLEAN NOT NULL,
    description VARCHAR(512) NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    CONSTRAINT uk_object_field_name UNIQUE (object_id, field_name),
    CONSTRAINT fk_field_object FOREIGN KEY (object_id) REFERENCES object_definition (object_id),
    INDEX idx_object_field_object_id (object_id)
);

CREATE TABLE field_relation (
    relation_id BIGINT NOT NULL PRIMARY KEY,
    relation_name VARCHAR(128) NULL,
    source_field_id BIGINT NOT NULL,
    target_object_id BIGINT NOT NULL,
    target_field_id BIGINT NOT NULL,
    relation_type VARCHAR(32) NOT NULL,
    description VARCHAR(512) NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    CONSTRAINT uk_field_relation UNIQUE (source_field_id, target_field_id, relation_type),
    CONSTRAINT fk_relation_source_field FOREIGN KEY (source_field_id) REFERENCES object_field (field_id),
    CONSTRAINT fk_relation_target_object FOREIGN KEY (target_object_id) REFERENCES object_definition (object_id),
    CONSTRAINT fk_relation_target_field FOREIGN KEY (target_field_id) REFERENCES object_field (field_id),
    INDEX idx_relation_target_object_id (target_object_id),
    INDEX idx_relation_target_field_id (target_field_id)
);
