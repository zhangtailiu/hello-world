ALTER TABLE field_relation DROP FOREIGN KEY fk_relation_source_field;
ALTER TABLE field_relation DROP FOREIGN KEY fk_relation_target_object;
ALTER TABLE field_relation DROP FOREIGN KEY fk_relation_target_field;
ALTER TABLE object_field DROP FOREIGN KEY fk_field_object;
ALTER TABLE object_definition DROP FOREIGN KEY fk_object_parent;

ALTER TABLE object_definition
    ADD INDEX idx_object_definition_parent_object_id (parent_object_id),
    MODIFY object_id BIGINT NOT NULL COMMENT '对象ID',
    MODIFY object_name VARCHAR(128) NOT NULL COMMENT '对象名称',
    MODIFY parent_object_id BIGINT NULL COMMENT '父对象ID',
    MODIFY description VARCHAR(512) NULL COMMENT '对象描述',
    MODIFY created_at DATETIME(6) NOT NULL COMMENT '创建时间',
    MODIFY updated_at DATETIME(6) NOT NULL COMMENT '更新时间',
    COMMENT='元数据对象定义表';

ALTER TABLE object_field
    MODIFY field_id BIGINT NOT NULL COMMENT '字段ID',
    MODIFY object_id BIGINT NOT NULL COMMENT '所属对象ID',
    MODIFY field_name VARCHAR(128) NOT NULL COMMENT '字段名称',
    MODIFY field_type VARCHAR(32) NOT NULL COMMENT '字段类型',
    MODIFY is_primary_key BOOLEAN NOT NULL COMMENT '是否主键字段',
    MODIFY description VARCHAR(512) NULL COMMENT '字段描述',
    MODIFY created_at DATETIME(6) NOT NULL COMMENT '创建时间',
    MODIFY updated_at DATETIME(6) NOT NULL COMMENT '更新时间',
    COMMENT='元数据对象字段表';

ALTER TABLE field_relation
    ADD INDEX idx_relation_source_field_id (source_field_id),
    MODIFY relation_id BIGINT NOT NULL COMMENT '关系ID',
    MODIFY relation_name VARCHAR(128) NULL COMMENT '关系名称',
    MODIFY source_field_id BIGINT NOT NULL COMMENT '源字段ID',
    MODIFY target_object_id BIGINT NOT NULL COMMENT '目标对象ID',
    MODIFY target_field_id BIGINT NOT NULL COMMENT '目标字段ID',
    MODIFY relation_type VARCHAR(32) NOT NULL COMMENT '关系类型',
    MODIFY description VARCHAR(512) NULL COMMENT '关系描述',
    MODIFY created_at DATETIME(6) NOT NULL COMMENT '创建时间',
    MODIFY updated_at DATETIME(6) NOT NULL COMMENT '更新时间',
    COMMENT='元数据字段关系表';
