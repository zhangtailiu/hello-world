package com.example.dmi.metadata.application;

import com.example.dmi.metadata.persistence.entity.FieldRelationEntity;
import com.example.dmi.metadata.persistence.entity.ObjectFieldEntity;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import org.springframework.stereotype.Component;

@Component
public class MetadataGraphPathFinder {

    /**
     * 查找请求对象两两之间所有最短路径经过的关系 ID。
     *
     * <p>对象集合从字段和关系中推断，适用于调用方没有单独传入对象全集的场景。</p>
     *
     * @param requestedObjectIds 需要连通的对象 ID 集合
     * @param relations 候选字段关系
     * @param fieldsById 按字段 ID 索引的字段定义
     * @return 所有最短路径覆盖到的关系 ID
     */
    public Set<Long> findAllShortestPathRelationIds(
            Set<Long> requestedObjectIds,
            List<FieldRelationEntity> relations,
            Map<Long, ObjectFieldEntity> fieldsById) {
        Set<Long> inferredObjectIds = new HashSet<>();
        fieldsById.values().stream()
            .map(ObjectFieldEntity::getObjectId)
            .forEach(inferredObjectIds::add);
        relations.stream()
            .map(FieldRelationEntity::getTargetObjectId)
            .forEach(inferredObjectIds::add);
        return findAllShortestPathRelationIds(requestedObjectIds, relations, fieldsById, inferredObjectIds);
    }

    /**
     * 查找请求对象两两之间所有最短路径经过的关系 ID。
     *
     * @param requestedObjectIds 需要连通的对象 ID 集合
     * @param relations 候选字段关系
     * @param fieldsById 按字段 ID 索引的字段定义
     * @param existingObjectIds 当前存在的对象 ID 集合
     * @return 所有最短路径覆盖到的关系 ID
     */
    public Set<Long> findAllShortestPathRelationIds(
            Set<Long> requestedObjectIds,
            List<FieldRelationEntity> relations,
            Map<Long, ObjectFieldEntity> fieldsById,
            Set<Long> existingObjectIds) {
        List<Long> requestedObjects = requestedObjectIds.stream()
            .filter(objectId -> objectId != null)
            .toList();
        if (requestedObjects.size() < 2) {
            return Set.of();
        }

        Map<Long, List<Edge>> adjacency = buildAdjacency(relations, fieldsById, existingObjectIds);
        Set<Long> relationIds = new LinkedHashSet<>();
        for (int sourceIndex = 0; sourceIndex < requestedObjects.size() - 1; sourceIndex++) {
            ShortestPaths shortestPaths = breadthFirstSearch(requestedObjects.get(sourceIndex), adjacency);
            for (int targetIndex = sourceIndex + 1; targetIndex < requestedObjects.size(); targetIndex++) {
                relationIds.addAll(shortestPaths.relationIdsTo(requestedObjects.get(targetIndex)));
            }
        }
        return relationIds;
    }

    private Map<Long, List<Edge>> buildAdjacency(
            List<FieldRelationEntity> relations,
            Map<Long, ObjectFieldEntity> fieldsById,
            Set<Long> existingObjectIds) {
        Map<Long, List<Edge>> adjacency = new HashMap<>();
        for (FieldRelationEntity relation : relations) {
            ObjectFieldEntity sourceField = fieldsById.get(relation.getSourceFieldId());
            ObjectFieldEntity targetField = fieldsById.get(relation.getTargetFieldId());
            // 无数据库外键约束，构图前需要跳过悬空字段、悬空对象和字段对象不匹配的关系。
            if (sourceField == null || targetField == null
                    || !existingObjectIds.contains(sourceField.getObjectId())
                    || !existingObjectIds.contains(relation.getTargetObjectId())
                    || !relation.getTargetObjectId().equals(targetField.getObjectId())) {
                continue;
            }

            Long sourceObjectId = sourceField.getObjectId();
            Long targetObjectId = relation.getTargetObjectId();
            adjacency.computeIfAbsent(sourceObjectId, ignored -> new ArrayList<>())
                .add(new Edge(targetObjectId, relation.getRelationId()));
            adjacency.computeIfAbsent(targetObjectId, ignored -> new ArrayList<>())
                .add(new Edge(sourceObjectId, relation.getRelationId()));
        }
        return adjacency;
    }

    ShortestPaths breadthFirstSearch(Long sourceObjectId, Map<Long, List<Edge>> adjacency) {
        Map<Long, Integer> distances = new HashMap<>();
        Map<Long, List<Predecessor>> predecessors = new HashMap<>();
        Queue<Long> queue = new ArrayDeque<>();
        distances.put(sourceObjectId, 0);
        queue.add(sourceObjectId);

        while (!queue.isEmpty()) {
            Long currentObjectId = queue.remove();
            int nextDistance = distances.get(currentObjectId) + 1;
            for (Edge edge : adjacency.getOrDefault(currentObjectId, List.of())) {
                Integer knownDistance = distances.get(edge.otherObjectId());
                if (knownDistance == null) {
                    distances.put(edge.otherObjectId(), nextDistance);
                    predecessors.computeIfAbsent(edge.otherObjectId(), ignored -> new ArrayList<>())
                        .add(new Predecessor(currentObjectId, edge.relationId()));
                    queue.add(edge.otherObjectId());
                } else if (knownDistance == nextDistance) {
                    predecessors.computeIfAbsent(edge.otherObjectId(), ignored -> new ArrayList<>())
                        .add(new Predecessor(currentObjectId, edge.relationId()));
                }
            }
        }
        return new ShortestPaths(distances, predecessors);
    }

    record ShortestPaths(
            Map<Long, Integer> distances,
            Map<Long, List<Predecessor>> predecessors) {

        Set<Long> relationIdsTo(Long targetObjectId) {
            if (!distances.containsKey(targetObjectId)) {
                return Set.of();
            }

            Set<Long> relationIds = new LinkedHashSet<>();
            Set<Long> visitedObjects = new HashSet<>();
            Queue<Long> queue = new ArrayDeque<>();
            queue.add(targetObjectId);

            // predecessor 记录的是从源点到各节点的最短路径父边，这里从目标反向回溯收集全部等长路径关系。
            while (!queue.isEmpty()) {
                Long currentObjectId = queue.remove();
                if (!visitedObjects.add(currentObjectId)) {
                    continue;
                }
                for (Predecessor predecessor : predecessors.getOrDefault(currentObjectId, List.of())) {
                    relationIds.add(predecessor.relationId());
                    queue.add(predecessor.objectId());
                }
            }
            return relationIds;
        }
    }

    record Edge(Long otherObjectId, Long relationId) {}

    record Predecessor(Long objectId, Long relationId) {}
}
