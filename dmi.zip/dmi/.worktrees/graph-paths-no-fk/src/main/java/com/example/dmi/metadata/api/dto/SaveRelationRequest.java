package com.example.dmi.metadata.api.dto;

import com.example.dmi.metadata.model.RelationType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * 保存字段关系的请求项。
 *
 * @param relationId 关系 ID；新增关系为空，更新关系时必须属于当前对象出边
 * @param relationName 关系名称
 * @param sourceFieldName 源字段名称，用于在当前对象字段列表中定位源字段
 * @param targetObjectId 目标对象 ID
 * @param targetFieldId 目标字段 ID
 * @param relationType 关系类型
 * @param description 关系描述
 */
public record SaveRelationRequest(
    Long relationId,
    String relationName,
    @NotBlank String sourceFieldName,
    @NotNull Long targetObjectId,
    @NotNull Long targetFieldId,
    @NotNull RelationType relationType,
    String description
) {}
