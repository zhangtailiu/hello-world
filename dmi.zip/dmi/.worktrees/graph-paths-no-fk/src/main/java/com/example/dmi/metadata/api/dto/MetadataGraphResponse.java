package com.example.dmi.metadata.api.dto;

import java.util.List;

/**
 * 元数据图谱响应。
 *
 * @param objects 图谱中包含的对象摘要
 * @param fields 图谱中包含的字段
 * @param relations 图谱中包含的字段关系
 */
public record MetadataGraphResponse(
    List<ObjectSummaryResponse> objects, List<FieldResponse> fields, List<RelationResponse> relations
) {}
