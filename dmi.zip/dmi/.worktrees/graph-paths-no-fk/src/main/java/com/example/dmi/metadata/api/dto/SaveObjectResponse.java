package com.example.dmi.metadata.api.dto;

/**
 * 保存对象定义响应。
 *
 * @param objectId 已保存的对象 ID
 * @param success 是否保存成功
 */
public record SaveObjectResponse(Long objectId, boolean success) {}
