package com.example.dmi;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.example.dmi.metadata.persistence.mapper")
public class DmiApplication {
    public static void main(String[] args) {
        SpringApplication.run(DmiApplication.class, args);
    }
}
