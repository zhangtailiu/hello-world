package com.example.dmi.metadata.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.dmi.metadata.persistence.entity.ObjectDefinitionEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ObjectDefinitionMapper extends BaseMapper<ObjectDefinitionEntity> {
    ObjectDefinitionEntity selectByIdForUpdate(@Param("objectId") Long objectId);
}
