package com.example.dmi.common.error;

public class MetadataException extends RuntimeException {
    private final ErrorCode code;
    private final Object details;

    public MetadataException(ErrorCode code, String message) {
        this(code, message, null);
    }

    public MetadataException(ErrorCode code, String message, Object details) {
        super(message);
        this.code = code;
        this.details = details;
    }

    public ErrorCode getCode() {
        return code;
    }

    public Object getDetails() {
        return details;
    }
}
