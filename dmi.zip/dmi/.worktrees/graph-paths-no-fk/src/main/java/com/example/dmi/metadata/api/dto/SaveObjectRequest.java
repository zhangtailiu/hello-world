package com.example.dmi.metadata.api.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;

/**
 * 保存对象定义请求。
 *
 * <p>更新已有对象时，字段列表和出边关系列表代表该对象的新完整定义。</p>
 *
 * @param objectId 对象 ID；新增对象为空，更新对象时必填
 * @param objectName 对象名称
 * @param parentObjectId 父对象 ID，顶层对象为空
 * @param description 对象描述
 * @param fields 对象字段完整列表
 * @param outgoingRelations 从当前对象出发的字段关系完整列表
 */
public record SaveObjectRequest(
    Long objectId,
    @NotBlank String objectName,
    Long parentObjectId,
    String description,
    @NotEmpty List<@Valid SaveFieldRequest> fields,
    @NotNull List<@Valid SaveRelationRequest> outgoingRelations
) {}
