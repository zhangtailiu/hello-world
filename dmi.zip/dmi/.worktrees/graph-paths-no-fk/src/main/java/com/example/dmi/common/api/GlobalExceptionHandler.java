package com.example.dmi.common.api;

import com.example.dmi.common.error.ErrorCode;
import com.example.dmi.common.error.MetadataException;
import java.util.Map;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(MetadataException.class)
    ResponseEntity<ApiError> handleMetadata(MetadataException exception) {
        return ResponseEntity.status(exception.getCode().getStatus())
            .body(new ApiError(exception.getCode().name(), exception.getMessage(), exception.getDetails()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<ApiError> handleValidation(MethodArgumentNotValidException exception) {
        return ResponseEntity.badRequest().body(new ApiError(ErrorCode.INVALID_DEFINITION.name(),
            "请求定义无效", Map.of("errors", exception.getBindingResult().getFieldErrors().stream()
                .map(error -> error.getField() + ": " + error.getDefaultMessage()).toList())));
    }

    @ExceptionHandler(DuplicateKeyException.class)
    ResponseEntity<ApiError> handleDuplicate(DuplicateKeyException exception) {
        return ResponseEntity.status(409).body(new ApiError(
            ErrorCode.OBJECT_NAME_CONFLICT.name(), "名称或关系定义重复", null));
    }
}
