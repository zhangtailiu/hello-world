package com.example.dmi.metadata.api.dto;

import com.example.dmi.metadata.model.FieldType;

/**
 * 对象字段响应。
 *
 * @param fieldId 字段 ID
 * @param objectId 字段所属对象 ID
 * @param fieldName 字段名称
 * @param fieldType 字段类型
 * @param primaryKey 是否为主键字段
 * @param description 字段描述
 */
public record FieldResponse(
    Long fieldId, Long objectId, String fieldName, FieldType fieldType, boolean primaryKey, String description
) {}
