package com.example.dmi.metadata.application;

import com.example.dmi.common.error.ErrorCode;
import com.example.dmi.common.error.MetadataException;
import com.example.dmi.metadata.api.dto.SaveObjectRequest;
import com.example.dmi.metadata.api.dto.SaveRelationRequest;
import java.util.HashSet;
import java.util.Set;
import org.springframework.stereotype.Component;

@Component
public class MetadataDefinitionValidator {
    public void validate(SaveObjectRequest request) {
        long primaryKeys = request.fields().stream().filter(field -> field.primaryKey()).count();
        require(primaryKeys == 1, "每个对象必须且只能有一个主键字段");

        Set<String> fieldNames = new HashSet<>();
        request.fields().forEach(field ->
            require(fieldNames.add(field.fieldName()), "对象内字段名称不能重复: " + field.fieldName()));

        Set<String> relationKeys = new HashSet<>();
        for (SaveRelationRequest relation : request.outgoingRelations()) {
            require(fieldNames.contains(relation.sourceFieldName()),
                "关系源字段不存在: " + relation.sourceFieldName());
            String key = relation.sourceFieldName() + "|" + relation.targetFieldId() + "|" + relation.relationType();
            require(relationKeys.add(key), "关系定义不能重复");
        }
    }

    private void require(boolean condition, String message) {
        if (!condition) {
            throw new MetadataException(ErrorCode.INVALID_DEFINITION, message);
        }
    }
}
