package com.example.dmi.metadata.model;

public enum FieldType {
    STRING, INTEGER, LONG, DECIMAL, BOOLEAN, DATE, DATETIME, JSON
}
