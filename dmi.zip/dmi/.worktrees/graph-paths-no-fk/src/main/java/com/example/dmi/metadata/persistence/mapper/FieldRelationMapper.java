package com.example.dmi.metadata.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.dmi.metadata.persistence.entity.FieldRelationEntity;
import java.util.Collection;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface FieldRelationMapper extends BaseMapper<FieldRelationEntity> {
    List<FieldRelationEntity> selectBySourceObjectId(@Param("objectId") Long objectId);
    List<FieldRelationEntity> selectByTargetObjectId(@Param("objectId") Long objectId);
    List<FieldRelationEntity> selectReferencingFields(@Param("fieldIds") Collection<Long> fieldIds);
    List<FieldRelationEntity> selectRelationsTouchingObject(@Param("objectId") Long objectId);
    List<FieldRelationEntity> selectRelationsWithinObjects(@Param("objectIds") Collection<Long> objectIds);
}
