package com.example.dmi.metadata.application;

import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.dmi.common.error.ErrorCode;
import com.example.dmi.common.error.MetadataException;
import com.example.dmi.metadata.api.dto.SaveFieldRequest;
import com.example.dmi.metadata.api.dto.SaveObjectRequest;
import com.example.dmi.metadata.api.dto.SaveObjectResponse;
import com.example.dmi.metadata.api.dto.SaveRelationRequest;
import com.example.dmi.metadata.persistence.entity.FieldRelationEntity;
import com.example.dmi.metadata.persistence.entity.ObjectDefinitionEntity;
import com.example.dmi.metadata.persistence.entity.ObjectFieldEntity;
import com.example.dmi.metadata.persistence.mapper.FieldRelationMapper;
import com.example.dmi.metadata.persistence.mapper.ObjectDefinitionMapper;
import com.example.dmi.metadata.persistence.mapper.ObjectFieldMapper;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MetadataSaveService {
    private final MetadataDefinitionValidator validator;
    private final ObjectDefinitionMapper objectMapper;
    private final ObjectFieldMapper fieldMapper;
    private final FieldRelationMapper relationMapper;

    public MetadataSaveService(MetadataDefinitionValidator validator, ObjectDefinitionMapper objectMapper,
                               ObjectFieldMapper fieldMapper, FieldRelationMapper relationMapper) {
        this.validator = validator;
        this.objectMapper = objectMapper;
        this.fieldMapper = fieldMapper;
        this.relationMapper = relationMapper;
    }

    /**
     * 保存对象定义。
     *
     * <p>新增对象时生成对象和字段 ID；更新对象时使用请求中的字段和出边关系全量覆盖旧定义。</p>
     *
     * @param request 对象定义保存请求
     * @return 保存结果
     */
    @Transactional
    public SaveObjectResponse save(SaveObjectRequest request) {
        validator.validate(request);
        validateParent(request.parentObjectId());
        if (request.objectId() == null) {
            return create(request);
        }
        return replace(request);
    }

    private SaveObjectResponse create(SaveObjectRequest request) {
        validateTargets(request.outgoingRelations());
        Long objectId = IdWorker.getId();
        LocalDateTime now = LocalDateTime.now();
        objectMapper.insert(new ObjectDefinitionEntity(
            objectId, request.objectName(), request.parentObjectId(), request.description(), now, now));
        Map<String, Long> fieldIds = insertNewFields(objectId, request.fields(), now);
        insertRelations(request.outgoingRelations(), fieldIds, now);
        return new SaveObjectResponse(objectId, true);
    }

    private SaveObjectResponse replace(SaveObjectRequest request) {
        Long objectId = request.objectId();
        ObjectDefinitionEntity existing = objectMapper.selectByIdForUpdate(objectId);
        if (existing == null) {
            throw new MetadataException(ErrorCode.OBJECT_NOT_FOUND, "对象不存在: " + objectId);
        }

        List<ObjectFieldEntity> oldFields = fieldsOf(objectId);
        Set<Long> oldFieldIds = oldFields.stream().map(ObjectFieldEntity::getFieldId).collect(java.util.stream.Collectors.toSet());
        List<FieldRelationEntity> oldRelations = relationMapper.selectBySourceObjectId(objectId);
        Set<Long> oldRelationIds = oldRelations.stream().map(FieldRelationEntity::getRelationId).collect(java.util.stream.Collectors.toSet());
        validateOwnedIds(request, oldFieldIds, oldRelationIds);
        validateTargets(request.outgoingRelations());

        // 保存接口采用全量覆盖语义：请求中未保留的旧字段会被删除，旧出边关系会整体重建。
        Set<Long> retainedFieldIds = new HashSet<>();
        request.fields().stream().map(SaveFieldRequest::fieldId).filter(java.util.Objects::nonNull)
            .forEach(retainedFieldIds::add);
        Set<Long> deletedFieldIds = new HashSet<>(oldFieldIds);
        deletedFieldIds.removeAll(retainedFieldIds);
        rejectRelationsTargetingDeletedFields(request.outgoingRelations(), deletedFieldIds);
        rejectExternalReferences(objectId, deletedFieldIds);

        oldRelations.forEach(relation -> relationMapper.deleteById(relation.getRelationId()));
        deletedFieldIds.forEach(fieldMapper::deleteById);

        LocalDateTime now = LocalDateTime.now();
        Map<String, Long> fieldIds = upsertFields(objectId, request.fields(), now);
        insertRelations(request.outgoingRelations(), fieldIds, now);
        existing.setObjectName(request.objectName());
        existing.setParentObjectId(request.parentObjectId());
        existing.setDescription(request.description());
        existing.setUpdatedAt(now);
        objectMapper.updateById(existing);
        return new SaveObjectResponse(objectId, true);
    }

    private void validateParent(Long parentObjectId) {
        if (parentObjectId != null && objectMapper.selectById(parentObjectId) == null) {
            throw new MetadataException(ErrorCode.TARGET_NOT_FOUND, "父对象不存在: " + parentObjectId);
        }
    }

    private void validateOwnedIds(SaveObjectRequest request, Set<Long> oldFieldIds, Set<Long> oldRelationIds) {
        boolean invalidField = request.fields().stream().map(SaveFieldRequest::fieldId)
            .filter(java.util.Objects::nonNull).anyMatch(id -> !oldFieldIds.contains(id));
        boolean invalidRelation = request.outgoingRelations().stream().map(SaveRelationRequest::relationId)
            .filter(java.util.Objects::nonNull).anyMatch(id -> !oldRelationIds.contains(id));
        if (invalidField || invalidRelation) {
            throw new MetadataException(ErrorCode.INVALID_DEFINITION, "字段或关系 ID 不属于当前对象");
        }
    }

    private void validateTargets(List<SaveRelationRequest> relations) {
        for (SaveRelationRequest relation : relations) {
            ObjectDefinitionEntity targetObject = objectMapper.selectById(relation.targetObjectId());
            ObjectFieldEntity targetField = fieldMapper.selectById(relation.targetFieldId());
            if (targetObject == null || targetField == null) {
                throw new MetadataException(ErrorCode.TARGET_NOT_FOUND, "关系目标对象或字段不存在");
            }
            if (!targetField.getObjectId().equals(relation.targetObjectId())) {
                throw new MetadataException(ErrorCode.INVALID_DEFINITION, "目标字段不属于目标对象");
            }
        }
    }

    private void rejectExternalReferences(Long objectId, Set<Long> deletedFieldIds) {
        if (deletedFieldIds.isEmpty()) {
            return;
        }
        List<FieldRelationEntity> references = relationMapper.selectReferencingFields(deletedFieldIds).stream()
            .filter(relation -> {
                ObjectFieldEntity source = fieldMapper.selectById(relation.getSourceFieldId());
                return source != null && !source.getObjectId().equals(objectId);
            }).toList();
        if (!references.isEmpty()) {
            throw new MetadataException(ErrorCode.FIELD_REFERENCED, "待删除字段仍被其他对象关系引用",
                Map.of("fieldIds", deletedFieldIds,
                    "relationIds", references.stream().map(FieldRelationEntity::getRelationId).toList()));
        }
    }

    private void rejectRelationsTargetingDeletedFields(List<SaveRelationRequest> relations, Set<Long> deletedFieldIds) {
        if (relations.stream().anyMatch(relation -> deletedFieldIds.contains(relation.targetFieldId()))) {
            throw new MetadataException(ErrorCode.INVALID_DEFINITION,
                "关系目标字段不能在同一次全量覆盖中删除",
                Map.of("targetFieldIds", relations.stream()
                    .map(SaveRelationRequest::targetFieldId)
                    .filter(deletedFieldIds::contains)
                    .distinct()
                    .toList()));
        }
    }

    private Map<String, Long> insertNewFields(Long objectId, List<SaveFieldRequest> fields, LocalDateTime now) {
        Map<String, Long> ids = new HashMap<>();
        for (SaveFieldRequest field : fields) {
            Long id = IdWorker.getId();
            fieldMapper.insert(toEntity(id, objectId, field, now, now));
            ids.put(field.fieldName(), id);
        }
        return ids;
    }

    private Map<String, Long> upsertFields(Long objectId, List<SaveFieldRequest> fields, LocalDateTime now) {
        Map<String, Long> ids = new HashMap<>();
        for (SaveFieldRequest field : fields) {
            Long id = field.fieldId() == null ? IdWorker.getId() : field.fieldId();
            ObjectFieldEntity existing = field.fieldId() == null ? null : fieldMapper.selectById(field.fieldId());
            LocalDateTime createdAt = existing == null ? now : existing.getCreatedAt();
            ObjectFieldEntity entity = toEntity(id, objectId, field, createdAt, now);
            if (existing == null) {
                fieldMapper.insert(entity);
            } else {
                fieldMapper.updateById(entity);
            }
            ids.put(field.fieldName(), id);
        }
        return ids;
    }

    private ObjectFieldEntity toEntity(Long id, Long objectId, SaveFieldRequest field,
                                       LocalDateTime createdAt, LocalDateTime updatedAt) {
        return new ObjectFieldEntity(id, objectId, field.fieldName(), field.fieldType().name(),
            field.primaryKey(), field.description(), createdAt, updatedAt);
    }

    private void insertRelations(List<SaveRelationRequest> relations, Map<String, Long> fieldIds, LocalDateTime now) {
        for (SaveRelationRequest relation : relations) {
            Long relationId = relation.relationId() == null ? IdWorker.getId() : relation.relationId();
            relationMapper.insert(new FieldRelationEntity(relationId, relation.relationName(),
                fieldIds.get(relation.sourceFieldName()), relation.targetObjectId(), relation.targetFieldId(),
                relation.relationType().name(), relation.description(), now, now));
        }
    }

    private List<ObjectFieldEntity> fieldsOf(Long objectId) {
        return fieldMapper.selectList(Wrappers.<ObjectFieldEntity>lambdaQuery()
            .eq(ObjectFieldEntity::getObjectId, objectId));
    }
}
