package com.example.dmi.common.error;

import org.springframework.http.HttpStatus;

public enum ErrorCode {
    INVALID_DEFINITION(HttpStatus.BAD_REQUEST),
    OBJECT_NOT_FOUND(HttpStatus.NOT_FOUND),
    TARGET_NOT_FOUND(HttpStatus.NOT_FOUND),
    OBJECT_NAME_CONFLICT(HttpStatus.CONFLICT),
    FIELD_NAME_CONFLICT(HttpStatus.CONFLICT),
    FIELD_REFERENCED(HttpStatus.CONFLICT);

    private final HttpStatus status;

    ErrorCode(HttpStatus status) {
        this.status = status;
    }

    public HttpStatus getStatus() {
        return status;
    }
}
