package com.example.dmi.metadata.persistence.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

/**
 * 对象定义持久化实体，对应元数据对象的基础信息。
 */
@TableName("object_definition")
public class ObjectDefinitionEntity {
    @TableId
    private Long objectId;
    private String objectName;
    private Long parentObjectId;
    private String description;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public ObjectDefinitionEntity() {}

    public ObjectDefinitionEntity(Long objectId, String objectName, Long parentObjectId, String description,
                                  LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.objectId = objectId;
        this.objectName = objectName;
        this.parentObjectId = parentObjectId;
        this.description = description;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Long getObjectId() { return objectId; }
    public void setObjectId(Long objectId) { this.objectId = objectId; }
    public String getObjectName() { return objectName; }
    public void setObjectName(String objectName) { this.objectName = objectName; }
    public Long getParentObjectId() { return parentObjectId; }
    public void setParentObjectId(Long parentObjectId) { this.parentObjectId = parentObjectId; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
