package com.example.dmi.metadata.api;

import com.example.dmi.metadata.api.dto.MetadataGraphResponse;
import com.example.dmi.metadata.api.dto.ObjectDefinitionResponse;
import com.example.dmi.metadata.api.dto.SaveObjectRequest;
import com.example.dmi.metadata.api.dto.SaveObjectResponse;
import com.example.dmi.metadata.application.MetadataQueryService;
import com.example.dmi.metadata.application.MetadataSaveService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 元数据定义与图谱查询接口。
 *
 * <p>提供对象定义保存、单对象详情查询和元数据关系图查询能力。</p>
 */
@RestController
@RequestMapping("/api/metadata")
public class MetadataController {
    private final MetadataSaveService saveService;
    private final MetadataQueryService queryService;

    public MetadataController(MetadataSaveService saveService, MetadataQueryService queryService) {
        this.saveService = saveService;
        this.queryService = queryService;
    }

    /**
     * 保存对象定义，并用请求中的字段和出边关系覆盖该对象的当前定义。
     *
     * @param request 对象定义保存请求
     * @return 保存结果
     */
    @PostMapping("/objects/save")
    public SaveObjectResponse save(@Valid @RequestBody SaveObjectRequest request) {
        return saveService.save(request);
    }

    /**
     * 查询单个对象的完整定义。
     *
     * @param objectId 对象 ID
     * @return 对象定义详情
     */
    @GetMapping("/objects/{objectId}")
    public ObjectDefinitionResponse getObject(@PathVariable Long objectId) {
        return queryService.getObject(objectId);
    }

    /**
     * 查询元数据关系图。
     *
     * @param objectIds 可选的对象 ID 列表；为空时返回全图
     * @return 元数据图谱
     */
    @GetMapping("/graph")
    public MetadataGraphResponse getGraph(@RequestParam(required = false) List<Long> objectIds) {
        return queryService.getGraph(objectIds == null ? List.of() : objectIds);
    }
}
