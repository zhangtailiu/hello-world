package com.example.dmi.common.api;

public record ApiError(String code, String message, Object details) {}
