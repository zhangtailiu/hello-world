package com.example.dmi.metadata.application;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.dmi.common.error.ErrorCode;
import com.example.dmi.common.error.MetadataException;
import com.example.dmi.metadata.api.dto.FieldResponse;
import com.example.dmi.metadata.api.dto.MetadataGraphResponse;
import com.example.dmi.metadata.api.dto.ObjectDefinitionResponse;
import com.example.dmi.metadata.api.dto.ObjectSummaryResponse;
import com.example.dmi.metadata.api.dto.RelationResponse;
import com.example.dmi.metadata.model.FieldType;
import com.example.dmi.metadata.model.RelationType;
import com.example.dmi.metadata.persistence.entity.FieldRelationEntity;
import com.example.dmi.metadata.persistence.entity.ObjectDefinitionEntity;
import com.example.dmi.metadata.persistence.entity.ObjectFieldEntity;
import com.example.dmi.metadata.persistence.mapper.FieldRelationMapper;
import com.example.dmi.metadata.persistence.mapper.ObjectDefinitionMapper;
import com.example.dmi.metadata.persistence.mapper.ObjectFieldMapper;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class MetadataQueryService {
    private final ObjectDefinitionMapper objectMapper;
    private final ObjectFieldMapper fieldMapper;
    private final FieldRelationMapper relationMapper;
    private final MetadataGraphPathFinder pathFinder;

    public MetadataQueryService(ObjectDefinitionMapper objectMapper, ObjectFieldMapper fieldMapper,
                                FieldRelationMapper relationMapper, MetadataGraphPathFinder pathFinder) {
        this.objectMapper = objectMapper;
        this.fieldMapper = fieldMapper;
        this.relationMapper = relationMapper;
        this.pathFinder = pathFinder;
    }

    /**
     * 查询对象完整定义，包括字段、有效出边关系和有效入边关系。
     *
     * @param objectId 对象 ID
     * @return 对象定义详情
     */
    public ObjectDefinitionResponse getObject(Long objectId) {
        ObjectDefinitionEntity object = requireObject(objectId);
        Map<Long, ObjectFieldEntity> fieldsById = allFieldsById();
        Set<Long> existingObjectIds = objectMapper.selectList(null).stream()
            .map(ObjectDefinitionEntity::getObjectId)
            .collect(Collectors.toSet());
        List<FieldResponse> fields = fieldsById.values().stream()
            .filter(field -> field.getObjectId().equals(objectId)).map(this::fieldResponse).sorted(fieldOrder()).toList();
        List<RelationResponse> outgoing = validRelations(
                relationMapper.selectBySourceObjectId(objectId), fieldsById, existingObjectIds).stream()
            .map(relation -> relationResponse(relation, fieldsById)).toList();
        List<RelationResponse> incoming = validRelations(
                relationMapper.selectByTargetObjectId(objectId), fieldsById, existingObjectIds).stream()
            .map(relation -> relationResponse(relation, fieldsById)).toList();
        return new ObjectDefinitionResponse(object.getObjectId(), object.getObjectName(), object.getParentObjectId(),
            object.getDescription(), fields, outgoing, incoming);
    }

    /**
     * 查询元数据图谱。
     *
     * <p>未指定对象时返回全图；指定一个对象时返回与其相邻的关系；
     * 指定多个对象时返回这些对象两两最短路径覆盖到的关系。</p>
     *
     * @param requestedObjectIds 需要查询的对象 ID 列表
     * @return 元数据图谱响应
     */
    public MetadataGraphResponse getGraph(List<Long> requestedObjectIds) {
        List<Long> objectIds = requestedObjectIds == null ? List.of() : requestedObjectIds.stream().distinct().toList();
        List<FieldRelationEntity> relations;
        Set<Long> includedObjectIds = new HashSet<>();
        Map<Long, ObjectFieldEntity> allFields = allFieldsById();
        List<ObjectDefinitionEntity> allObjects = objectMapper.selectList(null);
        Set<Long> existingObjectIds = allObjects.stream()
            .map(ObjectDefinitionEntity::getObjectId)
            .collect(Collectors.toSet());

        if (objectIds.isEmpty()) {
            includedObjectIds.addAll(existingObjectIds);
            relations = validRelations(relationMapper.selectList(Wrappers.<FieldRelationEntity>lambdaQuery()
                .orderByAsc(FieldRelationEntity::getRelationId)), allFields, existingObjectIds);
        } else if (objectIds.size() == 1) {
            requireObject(objectIds.get(0));
            includedObjectIds.add(objectIds.get(0));
            relations = validRelations(
                relationMapper.selectRelationsTouchingObject(objectIds.get(0)), allFields, existingObjectIds);
            relations.forEach(relation -> {
                includedObjectIds.add(allFields.get(relation.getSourceFieldId()).getObjectId());
                includedObjectIds.add(relation.getTargetObjectId());
            });
        } else {
            objectIds.forEach(this::requireObject);
            includedObjectIds.addAll(objectIds);
            List<FieldRelationEntity> allRelations = relationMapper.selectList(Wrappers.<FieldRelationEntity>lambdaQuery()
                .orderByAsc(FieldRelationEntity::getRelationId));
            allRelations = validRelations(allRelations, allFields, existingObjectIds);
            Set<Long> pathRelationIds = pathFinder.findAllShortestPathRelationIds(
                new HashSet<>(objectIds), allRelations, allFields, existingObjectIds);
            relations = allRelations.stream()
                .filter(relation -> pathRelationIds.contains(relation.getRelationId()))
                .toList();
            relations.forEach(relation -> {
                includedObjectIds.add(allFields.get(relation.getSourceFieldId()).getObjectId());
                includedObjectIds.add(relation.getTargetObjectId());
            });
        }

        List<ObjectSummaryResponse> objects = objectMapper.selectBatchIds(includedObjectIds).stream()
            .map(this::objectResponse).sorted(Comparator.comparing(ObjectSummaryResponse::objectId)).toList();
        List<FieldResponse> fields = allFields.values().stream()
            .filter(field -> includedObjectIds.contains(field.getObjectId()))
            .map(this::fieldResponse).sorted(fieldOrder()).toList();
        List<RelationResponse> responses = relations.stream()
            .map(relation -> relationResponse(relation, allFields))
            .sorted(Comparator.comparing(RelationResponse::relationId)).toList();
        return new MetadataGraphResponse(objects, fields, responses);
    }

    private List<FieldRelationEntity> validRelations(
            List<FieldRelationEntity> relations,
            Map<Long, ObjectFieldEntity> fieldsById,
            Set<Long> existingObjectIds) {
        return relations.stream()
            .filter(relation -> {
                ObjectFieldEntity sourceField = fieldsById.get(relation.getSourceFieldId());
                ObjectFieldEntity targetField = fieldsById.get(relation.getTargetFieldId());
                // 无数据库外键约束，查询结果只暴露源字段、目标对象和目标字段都一致存在的关系。
                return sourceField != null
                    && targetField != null
                    && existingObjectIds.contains(sourceField.getObjectId())
                    && existingObjectIds.contains(relation.getTargetObjectId())
                    && relation.getTargetObjectId().equals(targetField.getObjectId());
            })
            .toList();
    }

    private ObjectDefinitionEntity requireObject(Long objectId) {
        ObjectDefinitionEntity object = objectMapper.selectById(objectId);
        if (object == null) {
            throw new MetadataException(ErrorCode.OBJECT_NOT_FOUND, "对象不存在: " + objectId);
        }
        return object;
    }

    private Map<Long, ObjectFieldEntity> allFieldsById() {
        return fieldMapper.selectList(null).stream()
            .collect(Collectors.toMap(ObjectFieldEntity::getFieldId, Function.identity()));
    }

    private ObjectSummaryResponse objectResponse(ObjectDefinitionEntity object) {
        return new ObjectSummaryResponse(object.getObjectId(), object.getObjectName(),
            object.getParentObjectId(), object.getDescription());
    }

    private FieldResponse fieldResponse(ObjectFieldEntity field) {
        return new FieldResponse(field.getFieldId(), field.getObjectId(), field.getFieldName(),
            FieldType.valueOf(field.getFieldType()), Boolean.TRUE.equals(field.getIsPrimaryKey()), field.getDescription());
    }

    private RelationResponse relationResponse(FieldRelationEntity relation, Map<Long, ObjectFieldEntity> fieldsById) {
        ObjectFieldEntity source = fieldsById.get(relation.getSourceFieldId());
        return new RelationResponse(relation.getRelationId(), relation.getRelationName(), source.getObjectId(),
            relation.getSourceFieldId(), relation.getTargetObjectId(), relation.getTargetFieldId(),
            RelationType.valueOf(relation.getRelationType()), relation.getDescription());
    }

    private Comparator<FieldResponse> fieldOrder() {
        return Comparator.comparing(FieldResponse::fieldId);
    }
}
