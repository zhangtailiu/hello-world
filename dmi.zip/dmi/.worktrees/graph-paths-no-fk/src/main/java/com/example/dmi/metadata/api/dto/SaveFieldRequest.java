package com.example.dmi.metadata.api.dto;

import com.example.dmi.metadata.model.FieldType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * 保存对象字段的请求项。
 *
 * @param fieldId 字段 ID；新增字段为空，更新字段时必须属于当前对象
 * @param fieldName 字段名称
 * @param fieldType 字段类型
 * @param primaryKey 是否为主键字段
 * @param description 字段描述
 */
public record SaveFieldRequest(
    Long fieldId,
    @NotBlank String fieldName,
    @NotNull FieldType fieldType,
    boolean primaryKey,
    String description
) {}
