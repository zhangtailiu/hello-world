package com.example.dmi.metadata.api.dto;

import com.example.dmi.metadata.model.RelationType;

/**
 * 字段关系响应。
 *
 * @param relationId 关系 ID
 * @param relationName 关系名称
 * @param sourceObjectId 源对象 ID
 * @param sourceFieldId 源字段 ID
 * @param targetObjectId 目标对象 ID
 * @param targetFieldId 目标字段 ID
 * @param relationType 关系类型
 * @param description 关系描述
 */
public record RelationResponse(
    Long relationId, String relationName, Long sourceObjectId, Long sourceFieldId,
    Long targetObjectId, Long targetFieldId, RelationType relationType, String description
) {}
