package com.example.dmi.metadata.api.dto;

/**
 * 对象摘要响应。
 *
 * @param objectId 对象 ID
 * @param objectName 对象名称
 * @param parentObjectId 父对象 ID，顶层对象为空
 * @param description 对象描述
 */
public record ObjectSummaryResponse(Long objectId, String objectName, Long parentObjectId, String description) {}
