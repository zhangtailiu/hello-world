package com.example.dmi.metadata.api.dto;

import java.util.List;

/**
 * 对象定义详情响应。
 *
 * @param objectId 对象 ID
 * @param objectName 对象名称
 * @param parentObjectId 父对象 ID，顶层对象为空
 * @param description 对象描述
 * @param fields 对象字段列表
 * @param outgoingRelations 从当前对象出发的字段关系
 * @param incomingRelations 指向当前对象的字段关系
 */
public record ObjectDefinitionResponse(
    Long objectId, String objectName, Long parentObjectId, String description,
    List<FieldResponse> fields,
    List<RelationResponse> outgoingRelations,
    List<RelationResponse> incomingRelations
) {}
