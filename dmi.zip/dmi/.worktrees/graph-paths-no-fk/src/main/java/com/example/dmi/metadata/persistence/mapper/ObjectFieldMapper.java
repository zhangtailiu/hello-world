package com.example.dmi.metadata.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.dmi.metadata.persistence.entity.ObjectFieldEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ObjectFieldMapper extends BaseMapper<ObjectFieldEntity> {}
