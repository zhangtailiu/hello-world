package com.example.dmi.metadata.api;

import com.example.dmi.metadata.api.dto.SaveFieldRequest;
import com.example.dmi.metadata.api.dto.SaveObjectRequest;
import com.example.dmi.metadata.api.dto.SaveObjectResponse;
import com.example.dmi.metadata.api.dto.SaveRelationRequest;
import com.example.dmi.metadata.application.MetadataSaveService;
import com.example.dmi.metadata.model.FieldType;
import com.example.dmi.metadata.model.RelationType;
import com.example.dmi.metadata.persistence.entity.ObjectFieldEntity;
import com.example.dmi.metadata.persistence.mapper.ObjectFieldMapper;
import com.example.dmi.support.MySqlIntegrationTest;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class MetadataControllerIntegrationTest extends MySqlIntegrationTest {
    @Autowired MockMvc mockMvc;
    @Autowired MetadataSaveService saveService;
    @Autowired ObjectFieldMapper fieldMapper;

    @Test
    void createsAndQueriesMetadata() throws Exception {
        String response = mockMvc.perform(post("/api/metadata/objects/save")
                .contentType(MediaType.APPLICATION_JSON)
                .content(validObjectJson("接口品牌")))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.success").value(true))
            .andExpect(jsonPath("$.objectId").isNumber())
            .andReturn().getResponse().getContentAsString();
        String objectId = response.replaceAll(".*\"objectId\":(\\d+).*", "$1");

        mockMvc.perform(get("/api/metadata/objects/{objectId}", objectId))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.objectName").value("接口品牌"));
        mockMvc.perform(get("/api/metadata/graph").param("objectIds", objectId))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.objects.length()").value(1));
    }

    @Test
    void returnsStructuredErrors() throws Exception {
        mockMvc.perform(post("/api/metadata/objects/save")
                .contentType(MediaType.APPLICATION_JSON)
                .content("""
                    {"objectName":"无主键","fields":[{"fieldName":"name","fieldType":"STRING","primaryKey":false}],
                     "outgoingRelations":[]}
                    """))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.code").value("INVALID_DEFINITION"));

        mockMvc.perform(get("/api/metadata/objects/-1"))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.code").value("OBJECT_NOT_FOUND"));
    }

    @Test
    void graphIncludesIntermediateObjectsOnShortestPath() throws Exception {
        Long brandId = create("接口路径品牌", List.of());
        Long productId = create("接口路径产品", List.of(relation("brand_id", brandId, fieldId(brandId, "id"))));
        Long seriesId = create("接口路径系列", List.of(relation("product_id", productId, fieldId(productId, "id"))));

        mockMvc.perform(get("/api/metadata/graph")
                .param("objectIds", brandId + "," + seriesId))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.objects.length()").value(3))
            .andExpect(jsonPath("$.objects[*].objectId").value(
                org.hamcrest.Matchers.containsInAnyOrder(brandId, productId, seriesId)))
            .andExpect(jsonPath("$.relations.length()").value(2));
    }

    private String validObjectJson(String name) {
        return """
            {"objectName":"%s","fields":[{"fieldName":"id","fieldType":"STRING","primaryKey":true}],
             "outgoingRelations":[]}
            """.formatted(name);
    }

    private Long create(String name, List<SaveRelationRequest> relations) {
        List<SaveFieldRequest> fields = relations.isEmpty()
            ? List.of(field("id", true))
            : List.of(field("id", true), field(relations.get(0).sourceFieldName(), false));
        SaveObjectResponse response = saveService.save(new SaveObjectRequest(null, name, null, null, fields, relations));
        return response.objectId();
    }

    private SaveFieldRequest field(String name, boolean primary) {
        return new SaveFieldRequest(null, name, FieldType.STRING, primary, null);
    }

    private SaveRelationRequest relation(String source, Long targetObject, Long targetField) {
        return new SaveRelationRequest(null, "关联", source, targetObject, targetField, RelationType.MANY_TO_ONE, null);
    }

    private Long fieldId(Long objectId, String name) {
        return fieldMapper.selectList(null).stream()
            .filter(field -> field.getObjectId().equals(objectId) && field.getFieldName().equals(name))
            .map(ObjectFieldEntity::getFieldId).findFirst().orElseThrow();
    }
}
