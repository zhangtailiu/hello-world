package com.example.dmi.metadata.application;

import com.example.dmi.common.error.ErrorCode;
import com.example.dmi.common.error.MetadataException;
import com.example.dmi.metadata.api.dto.MetadataGraphResponse;
import com.example.dmi.metadata.api.dto.ObjectDefinitionResponse;
import com.example.dmi.metadata.api.dto.SaveFieldRequest;
import com.example.dmi.metadata.api.dto.SaveObjectRequest;
import com.example.dmi.metadata.api.dto.SaveObjectResponse;
import com.example.dmi.metadata.api.dto.SaveRelationRequest;
import com.example.dmi.metadata.model.FieldType;
import com.example.dmi.metadata.model.RelationType;
import com.example.dmi.metadata.persistence.entity.ObjectFieldEntity;
import com.example.dmi.metadata.persistence.mapper.ObjectFieldMapper;
import com.example.dmi.support.MySqlIntegrationTest;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@SpringBootTest
@Transactional
class MetadataQueryServiceIntegrationTest extends MySqlIntegrationTest {
    @Autowired MetadataSaveService saveService;
    @Autowired MetadataQueryService queryService;
    @Autowired ObjectFieldMapper fieldMapper;
    @Autowired JdbcTemplate jdbcTemplate;
    Long brandId;
    Long productId;
    Long seriesId;
    Long provinceId;

    @BeforeEach
    void setUp() {
        brandId = create("品牌查询", List.of());
        productId = create("产品查询", List.of(relation("brand_id", brandId, fieldId(brandId, "id"))));
        seriesId = create("系列查询", List.of(relation("product_id", productId, fieldId(productId, "id"))));
        provinceId = create("省查询", List.of());
    }

    @Test
    void getObjectReturnsFieldsAndBothRelationDirections() {
        ObjectDefinitionResponse product = queryService.getObject(productId);

        assertThat(product.fields()).extracting("fieldName").contains("id", "brand_id");
        assertThat(product.outgoingRelations()).hasSize(1);
        assertThat(product.incomingRelations()).hasSize(1);
        assertThatThrownBy(() -> queryService.getObject(-1L))
            .isInstanceOfSatisfying(MetadataException.class,
                exception -> assertThat(exception.getCode()).isEqualTo(ErrorCode.OBJECT_NOT_FOUND));
    }

    @Test
    void graphSupportsAllSingleAndMultipleObjectQueries() {
        MetadataGraphResponse all = queryService.getGraph(List.of());
        assertThat(all.objects()).extracting("objectId").contains(brandId, productId, seriesId, provinceId);

        MetadataGraphResponse one = queryService.getGraph(List.of(productId));
        assertThat(one.objects()).extracting("objectId").containsExactlyInAnyOrder(brandId, productId, seriesId);
        assertThat(one.relations()).hasSize(2);

        MetadataGraphResponse selected = queryService.getGraph(List.of(brandId, seriesId));
        assertThat(selected.objects()).extracting("objectId")
            .containsExactlyInAnyOrder(brandId, productId, seriesId);
        assertThat(selected.relations()).hasSize(2);
    }

    @Test
    void graphKeepsRequestedObjectsWhenNoPathExists() {
        MetadataGraphResponse selected = queryService.getGraph(List.of(brandId, provinceId));

        assertThat(selected.objects()).extracting("objectId").containsExactlyInAnyOrder(brandId, provinceId);
        assertThat(selected.relations()).isEmpty();
    }

    @Test
    void graphIgnoresMissingIntermediateObjectInsteadOfCreatingFalsePath() {
        withoutForeignKeys(() -> jdbcTemplate.update(
            "DELETE FROM object_definition WHERE object_id = ?", productId));

        MetadataGraphResponse selected = queryService.getGraph(List.of(brandId, seriesId));

        assertThat(selected.objects()).extracting("objectId").containsExactlyInAnyOrder(brandId, seriesId);
        assertThat(selected.relations()).isEmpty();
    }

    @Test
    void graphOmitsRelationsWithMissingSourceOrTargetFields() {
        withoutForeignKeys(() -> {
            fieldMapper.deleteById(fieldId(productId, "brand_id"));
            fieldMapper.deleteById(fieldId(productId, "id"));
        });

        MetadataGraphResponse graph = queryService.getGraph(List.of());

        assertThat(graph.relations()).isEmpty();
    }

    @Test
    void graphIgnoresTargetFieldOwnedByDifferentObject() {
        jdbcTemplate.update("""
            UPDATE field_relation
            SET target_field_id = ?
            WHERE target_object_id = ?
            """, fieldId(provinceId, "id"), brandId);

        MetadataGraphResponse selected = queryService.getGraph(List.of(brandId, productId));

        assertThat(selected.objects()).extracting("objectId").containsExactlyInAnyOrder(brandId, productId);
        assertThat(selected.relations()).isEmpty();
    }

    @Test
    void getObjectOmitsRelationsWithMissingSourceField() {
        withoutForeignKeys(() -> fieldMapper.deleteById(fieldId(productId, "brand_id")));

        assertThatCode(() -> queryService.getObject(brandId)).doesNotThrowAnyException();
        ObjectDefinitionResponse brand = queryService.getObject(brandId);

        assertThat(brand.incomingRelations()).isEmpty();
    }

    @Test
    void getObjectOmitsRelationsWhenTargetFieldBelongsToDifferentObject() {
        jdbcTemplate.update("""
            UPDATE field_relation
            SET target_field_id = ?
            WHERE target_object_id = ?
            """, fieldId(provinceId, "id"), brandId);

        assertThatCode(() -> queryService.getObject(productId)).doesNotThrowAnyException();
        assertThatCode(() -> queryService.getObject(brandId)).doesNotThrowAnyException();
        ObjectDefinitionResponse product = queryService.getObject(productId);
        ObjectDefinitionResponse brand = queryService.getObject(brandId);

        assertThat(product.outgoingRelations()).isEmpty();
        assertThat(brand.incomingRelations()).isEmpty();
    }

    @Test
    void duplicateRequestedObjectIdsDoNotChangeGraph() {
        MetadataGraphResponse distinct = queryService.getGraph(List.of(brandId, seriesId));
        MetadataGraphResponse duplicated = queryService.getGraph(List.of(brandId, brandId, seriesId, seriesId));

        assertThat(duplicated).isEqualTo(distinct);
    }

    private Long create(String name, List<SaveRelationRequest> relations) {
        List<SaveFieldRequest> fields = relations.isEmpty()
            ? List.of(field("id", true))
            : List.of(field("id", true), field(relations.get(0).sourceFieldName(), false));
        SaveObjectResponse response = saveService.save(new SaveObjectRequest(null, name, null, null, fields, relations));
        return response.objectId();
    }

    private SaveFieldRequest field(String name, boolean primary) {
        return new SaveFieldRequest(null, name, FieldType.STRING, primary, null);
    }

    private SaveRelationRequest relation(String source, Long targetObject, Long targetField) {
        return new SaveRelationRequest(null, "关联", source, targetObject, targetField, RelationType.MANY_TO_ONE, null);
    }

    private Long fieldId(Long objectId, String name) {
        return fieldMapper.selectList(null).stream()
            .filter(field -> field.getObjectId().equals(objectId) && field.getFieldName().equals(name))
            .map(ObjectFieldEntity::getFieldId).findFirst().orElseThrow();
    }

    private void withoutForeignKeys(Runnable action) {
        jdbcTemplate.execute("SET FOREIGN_KEY_CHECKS = 0");
        try {
            action.run();
        } finally {
            jdbcTemplate.execute("SET FOREIGN_KEY_CHECKS = 1");
        }
    }
}
