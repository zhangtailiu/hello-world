package com.example.dmi.metadata.application;

import com.example.dmi.common.error.ErrorCode;
import com.example.dmi.common.error.MetadataException;
import com.example.dmi.metadata.api.dto.SaveFieldRequest;
import com.example.dmi.metadata.api.dto.SaveObjectRequest;
import com.example.dmi.metadata.api.dto.SaveRelationRequest;
import com.example.dmi.metadata.model.FieldType;
import com.example.dmi.metadata.model.RelationType;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class MetadataDefinitionValidatorTest {
    private final MetadataDefinitionValidator validator = new MetadataDefinitionValidator();

    @Test
    void acceptsValidDefinition() {
        validator.validate(request(
            List.of(field("id", true), field("brand_id", false)),
            List.of(relation("brand_id"))));
    }

    @Test
    void rejectsDefinitionWithoutExactlyOnePrimaryKey() {
        assertInvalid(request(List.of(field("id", false)), List.of()));
        assertInvalid(request(List.of(field("id", true), field("code", true)), List.of()));
    }

    @Test
    void rejectsDuplicateFieldNames() {
        assertInvalid(request(List.of(field("id", true), field("id", false)), List.of()));
    }

    @Test
    void rejectsUnknownRelationSourceFieldName() {
        assertInvalid(request(List.of(field("id", true)), List.of(relation("brand_id"))));
    }

    private void assertInvalid(SaveObjectRequest request) {
        assertThatThrownBy(() -> validator.validate(request))
            .isInstanceOfSatisfying(MetadataException.class,
                exception -> assertThat(exception.getCode()).isEqualTo(ErrorCode.INVALID_DEFINITION));
    }

    private SaveObjectRequest request(List<SaveFieldRequest> fields, List<SaveRelationRequest> relations) {
        return new SaveObjectRequest(null, "产品", null, null, fields, relations);
    }

    private SaveFieldRequest field(String name, boolean primary) {
        return new SaveFieldRequest(null, name, FieldType.STRING, primary, null);
    }

    private SaveRelationRequest relation(String sourceFieldName) {
        return new SaveRelationRequest(
            null, "所属品牌", sourceFieldName, 1L, 2L, RelationType.MANY_TO_ONE, null);
    }
}
