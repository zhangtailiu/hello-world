package com.example.dmi.metadata.application;

import com.example.dmi.metadata.persistence.entity.FieldRelationEntity;
import com.example.dmi.metadata.persistence.entity.ObjectFieldEntity;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class MetadataGraphPathFinderTest {
    private final MetadataGraphPathFinder pathFinder = new MetadataGraphPathFinder();

    @Test
    void traversesRelationsInReverseFromBrandToSeries() {
        Map<Long, ObjectFieldEntity> fields = Map.of(
            11L, field(11L, 1L),
            21L, field(21L, 2L),
            31L, field(31L, 3L));
        List<FieldRelationEntity> relations = List.of(
            relation(101L, 11L, 2L),
            relation(102L, 21L, 3L));

        Set<Long> result = pathFinder.findAllShortestPathRelationIds(
            Set.of(3L, 1L), relations, fields, Set.of(1L, 2L, 3L));

        assertThat(result).containsExactlyInAnyOrder(101L, 102L);
    }

    @Test
    void returnsEveryRelationOnEqualLengthShortestPaths() {
        Map<Long, ObjectFieldEntity> fields = Map.of(
            11L, field(11L, 1L),
            21L, field(21L, 2L),
            12L, field(12L, 1L),
            31L, field(31L, 3L),
            41L, field(41L, 4L));
        List<FieldRelationEntity> relations = List.of(
            relation(101L, 11L, 2L),
            relation(102L, 21L, 4L),
            relation(103L, 12L, 3L),
            relation(104L, 31L, 4L));

        Set<Long> result = pathFinder.findAllShortestPathRelationIds(
            Set.of(1L, 4L), relations, fields, Set.of(1L, 2L, 3L, 4L));

        assertThat(result).containsExactlyInAnyOrder(101L, 102L, 103L, 104L);
    }

    @Test
    void returnsEmptyWhenNoPathExistsAndIgnoresBrokenRelations() {
        Map<Long, ObjectFieldEntity> fields = Map.of(11L, field(11L, 1L));
        List<FieldRelationEntity> relations = List.of(
            relation(101L, 11L, 3L),
            relation(999L, 999L, 2L));

        Set<Long> result = pathFinder.findAllShortestPathRelationIds(
            Set.of(1L, 2L), relations, fields, Set.of(1L, 2L, 3L));

        assertThat(result).isEmpty();
    }

    @Test
    void excludesLongerDetourRelationsWhenGraphContainsACycle() {
        Map<Long, ObjectFieldEntity> fields = Map.of(
            11L, field(11L, 1L),
            21L, field(21L, 2L),
            12L, field(12L, 1L),
            31L, field(31L, 3L),
            41L, field(41L, 4L),
            51L, field(51L, 5L),
            61L, field(61L, 6L));
        List<FieldRelationEntity> relations = List.of(
            relation(101L, 11L, 2L),
            relation(102L, 21L, 4L),
            relation(103L, 12L, 3L),
            relation(104L, 31L, 5L),
            relation(105L, 51L, 6L),
            relation(106L, 61L, 3L),
            relation(107L, 51L, 4L));

        Set<Long> result = pathFinder.findAllShortestPathRelationIds(
            Set.of(1L, 4L), relations, fields, Set.of(1L, 2L, 3L, 4L, 5L, 6L));

        assertThat(result).containsExactlyInAnyOrder(101L, 102L);
    }

    @Test
    void returnsUnionOfShortestPathsForEveryRequestedObjectPair() {
        Map<Long, ObjectFieldEntity> fields = Map.of(
            11L, field(11L, 1L),
            21L, field(21L, 2L),
            22L, field(22L, 2L),
            31L, field(31L, 3L),
            41L, field(41L, 4L));
        List<FieldRelationEntity> relations = List.of(
            relation(101L, 11L, 2L),
            relation(102L, 21L, 3L),
            relation(103L, 22L, 4L));

        Set<Long> result = pathFinder.findAllShortestPathRelationIds(
            Set.of(1L, 3L, 4L), relations, fields, Set.of(1L, 2L, 3L, 4L));

        assertThat(result).containsExactlyInAnyOrder(101L, 102L, 103L);
    }

    @Test
    void runsBreadthFirstSearchOnlyOncePerRequestedSourceObject() {
        CountingPathFinder observedPathFinder = new CountingPathFinder();
        Map<Long, ObjectFieldEntity> fields = Map.of(
            11L, field(11L, 1L),
            21L, field(21L, 2L),
            31L, field(31L, 3L),
            41L, field(41L, 4L));
        List<FieldRelationEntity> relations = List.of(
            relation(101L, 11L, 2L),
            relation(102L, 21L, 3L),
            relation(103L, 31L, 4L));

        observedPathFinder.findAllShortestPathRelationIds(
            Set.of(1L, 2L, 3L, 4L), relations, fields, Set.of(1L, 2L, 3L, 4L));

        assertThat(observedPathFinder.searchCount).isEqualTo(3);
        assertThat(observedPathFinder.searchedSourceIds).hasSize(3);
    }

    @Test
    void ignoresRelationsWithMissingObjectsOrInvalidFields() {
        Map<Long, ObjectFieldEntity> fields = Map.of(
            11L, field(11L, 1L),
            21L, field(21L, 2L),
            31L, field(31L, 3L),
            41L, field(41L, 4L));
        List<FieldRelationEntity> relations = List.of(
            relation(101L, 11L, 2L),
            relation(102L, 21L, 3L),
            relation(103L, 999L, 3L),
            relation(104L, 31L, 4L),
            new FieldRelationEntity(105L, "wrong-target-field", 11L, 2L, 31L,
                "MANY_TO_ONE", null, null, null));

        Set<Long> result = pathFinder.findAllShortestPathRelationIds(
            Set.of(1L, 3L, 4L), relations, fields, Set.of(1L, 3L, 4L));

        assertThat(result).containsExactly(104L);
    }

    private ObjectFieldEntity field(long fieldId, long objectId) {
        return new ObjectFieldEntity(fieldId, objectId, "field-" + fieldId, "STRING", false,
            null, null, null);
    }

    private FieldRelationEntity relation(long relationId, long sourceFieldId, long targetObjectId) {
        return new FieldRelationEntity(relationId, "relation-" + relationId, sourceFieldId,
            targetObjectId, targetObjectId * 10 + 1, "MANY_TO_ONE", null, null, null);
    }

    private static class CountingPathFinder extends MetadataGraphPathFinder {
        private int searchCount;
        private final Set<Long> searchedSourceIds = new HashSet<>();

        @Override
        ShortestPaths breadthFirstSearch(Long sourceObjectId, Map<Long, List<Edge>> adjacency) {
            searchCount++;
            searchedSourceIds.add(sourceObjectId);
            return super.breadthFirstSearch(sourceObjectId, adjacency);
        }
    }
}
