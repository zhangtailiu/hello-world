package com.example.dmi.metadata.application;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.dmi.common.error.ErrorCode;
import com.example.dmi.common.error.MetadataException;
import com.example.dmi.metadata.api.dto.SaveFieldRequest;
import com.example.dmi.metadata.api.dto.SaveObjectRequest;
import com.example.dmi.metadata.api.dto.SaveObjectResponse;
import com.example.dmi.metadata.api.dto.SaveRelationRequest;
import com.example.dmi.metadata.model.FieldType;
import com.example.dmi.metadata.model.RelationType;
import com.example.dmi.metadata.persistence.entity.ObjectFieldEntity;
import com.example.dmi.metadata.persistence.mapper.FieldRelationMapper;
import com.example.dmi.metadata.persistence.mapper.ObjectDefinitionMapper;
import com.example.dmi.metadata.persistence.mapper.ObjectFieldMapper;
import com.example.dmi.support.MySqlIntegrationTest;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@SpringBootTest
@Transactional
class MetadataSaveServiceIntegrationTest extends MySqlIntegrationTest {
    @Autowired MetadataSaveService service;
    @Autowired ObjectDefinitionMapper objectMapper;
    @Autowired ObjectFieldMapper fieldMapper;
    @Autowired FieldRelationMapper relationMapper;

    @Test
    void createsObjectAndResolvesSourceFieldName() {
        SaveObjectResponse brand = service.save(object(null, "品牌",
            List.of(field(null, "id", true), field(null, "name", false)), List.of()));
        Long brandIdField = fieldId(brand.objectId(), "id");

        SaveObjectResponse product = service.save(object(null, "产品",
            List.of(field(null, "id", true), field(null, "brand_id", false)),
            List.of(relation(null, "brand_id", brand.objectId(), brandIdField))));

        assertThat(objectMapper.selectById(product.objectId())).isNotNull();
        assertThat(relationMapper.selectBySourceObjectId(product.objectId()))
            .singleElement()
            .satisfies(relation -> {
                assertThat(relation.getSourceFieldId()).isEqualTo(fieldId(product.objectId(), "brand_id"));
                assertThat(relation.getTargetFieldId()).isEqualTo(brandIdField);
            });
    }

    @Test
    void replacesObjectDefinitionAndOutgoingRelations() {
        SaveObjectResponse brand = service.save(object(null, "品牌修改目标",
            List.of(field(null, "id", true)), List.of()));
        SaveObjectResponse product = service.save(object(null, "产品修改目标",
            List.of(field(null, "id", true), field(null, "legacy", false)), List.of()));

        Long productId = product.objectId();
        Long retainedId = fieldId(productId, "id");
        service.save(object(productId, "产品修改目标",
            List.of(field(retainedId, "product_id", true), field(null, "brand_id", false)),
            List.of(relation(null, "brand_id", brand.objectId(), fieldId(brand.objectId(), "id")))));

        assertThat(fields(productId)).extracting(ObjectFieldEntity::getFieldName)
            .containsExactlyInAnyOrder("product_id", "brand_id");
        assertThat(relationMapper.selectBySourceObjectId(productId)).hasSize(1);
    }

    @Test
    void rejectsDeletingFieldReferencedByAnotherObjectAndRollsBack() {
        SaveObjectResponse brand = service.save(object(null, "品牌引用保护",
            List.of(field(null, "id", true), field(null, "name", false)), List.of()));
        service.save(object(null, "产品引用保护",
            List.of(field(null, "id", true), field(null, "brand_id", false)),
            List.of(relation(null, "brand_id", brand.objectId(), fieldId(brand.objectId(), "id")))));

        assertThatThrownBy(() -> service.save(object(brand.objectId(), "品牌引用保护",
            List.of(field(fieldId(brand.objectId(), "name"), "name", true)), List.of())))
            .isInstanceOfSatisfying(MetadataException.class,
                exception -> assertThat(exception.getCode()).isEqualTo(ErrorCode.FIELD_REFERENCED));

        assertThat(fields(brand.objectId())).extracting(ObjectFieldEntity::getFieldName)
            .containsExactlyInAnyOrder("id", "name");
    }

    @Test
    void rejectsRelationTargetingFieldDeletedBySameReplacement() {
        SaveObjectResponse object = service.save(object(null, "自引用保护",
            List.of(field(null, "id", true), field(null, "parent_id", false)), List.of()));
        Long idField = fieldId(object.objectId(), "id");
        Long parentField = fieldId(object.objectId(), "parent_id");

        assertThatThrownBy(() -> service.save(object(object.objectId(), "自引用保护",
            List.of(field(parentField, "parent_id", true)),
            List.of(relation(null, "parent_id", object.objectId(), idField)))))
            .isInstanceOfSatisfying(MetadataException.class,
                exception -> assertThat(exception.getCode()).isEqualTo(ErrorCode.INVALID_DEFINITION));

        assertThat(fields(object.objectId())).extracting(ObjectFieldEntity::getFieldName)
            .containsExactlyInAnyOrder("id", "parent_id");
    }

    private List<ObjectFieldEntity> fields(Long objectId) {
        return fieldMapper.selectList(Wrappers.<ObjectFieldEntity>lambdaQuery()
            .eq(ObjectFieldEntity::getObjectId, objectId));
    }

    private Long fieldId(Long objectId, String name) {
        return fields(objectId).stream().filter(field -> field.getFieldName().equals(name))
            .findFirst().orElseThrow().getFieldId();
    }

    private SaveObjectRequest object(Long id, String name, List<SaveFieldRequest> fields,
                                     List<SaveRelationRequest> relations) {
        return new SaveObjectRequest(id, name, null, null, fields, relations);
    }

    private SaveFieldRequest field(Long id, String name, boolean primary) {
        return new SaveFieldRequest(id, name, FieldType.STRING, primary, null);
    }

    private SaveRelationRequest relation(Long id, String source, Long targetObject, Long targetField) {
        return new SaveRelationRequest(id, "关联", source, targetObject, targetField, RelationType.MANY_TO_ONE, null);
    }
}
