package com.example.dmi;

import com.example.dmi.support.MySqlIntegrationTest;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmiApplicationTest extends MySqlIntegrationTest {
    @Test
    void contextLoads() {
    }
}
