# 元数据服务设计规格

## 1. 目标

本期建设一个元数据驱动的对象模型服务，用于定义对象、对象字段以及对象字段之间的关系。

对象定义可用于描述品牌、产品、系列、省、市、区等业务模型。后续系统将依据这些元数据把实例写入 Neo4j，并使用 Cypher 执行对象下钻和组合查询。本期只实现元数据能力，不实现实例保存、Neo4j 写入或 Cypher 查询。

## 2. 技术栈

- Java 17
- Spring Boot 3
- MyBatis-Plus
- MySQL

## 3. 领域规则

### 3.1 对象与字段

- 对象可包含多个字段。
- 每个对象必须且只能包含一个主键字段，通过 `is_primary_key` 标识。
- `parent_object_id` 仅用于提示对象层级，不作为真实关联依据。
- 字段包含数据类型，但本期不负责实例值的类型校验。

### 3.2 字段关系

- 所有对象关系统一表示为源字段到目标字段的等值关联。
- 关系方向固定按照源对象到目标对象定义。
- `relation_type` 支持 `ONE_TO_ONE`、`ONE_TO_MANY`、`MANY_TO_ONE`、`MANY_TO_MANY`。
- `MANY_TO_MANY` 在实际数据模型中通过中间对象拆解为普通字段关系；关系类型仍可作为元数据描述。
- 关系中的源字段必须属于源对象。
- 关系中的目标字段必须属于目标对象。

例如：

```text
产品.brand_id --MANY_TO_ONE--> 品牌.id
```

## 4. 数据模型

所有主键 ID 均由服务端生成。建议使用分布式唯一 ID，数据库字段使用 `BIGINT`。

### 4.1 `object_definition`

| 字段 | 类型 | 约束 | 说明 |
|---|---|---|---|
| `object_id` | BIGINT | 主键 | 对象唯一标识 |
| `object_name` | VARCHAR(128) | 唯一、非空 | 对象名称 |
| `parent_object_id` | BIGINT | 可空 | 父对象提示 |
| `description` | VARCHAR(512) | 可空 | 对象语义描述 |
| `created_at` | DATETIME | 非空 | 创建时间 |
| `updated_at` | DATETIME | 非空 | 更新时间 |

约束：

- `object_name` 全局唯一。
- `parent_object_id` 存在时必须指向已有对象。
- 父对象仅作为提示，不参与字段关系查询。

### 4.2 `object_field`

| 字段 | 类型 | 约束 | 说明 |
|---|---|---|---|
| `field_id` | BIGINT | 主键 | 字段唯一标识 |
| `object_id` | BIGINT | 外键、非空 | 所属对象 |
| `field_name` | VARCHAR(128) | 非空 | 字段名称 |
| `field_type` | VARCHAR(32) | 非空 | 字段数据类型 |
| `is_primary_key` | BOOLEAN | 非空 | 是否为对象主键字段 |
| `description` | VARCHAR(512) | 可空 | 字段语义描述 |
| `created_at` | DATETIME | 非空 | 创建时间 |
| `updated_at` | DATETIME | 非空 | 更新时间 |

约束：

- 同一对象内 `field_name` 唯一。
- 每个对象必须且只能有一个 `is_primary_key = true` 的字段。
- 支持的 `field_type` 枚举为 `STRING`、`INTEGER`、`LONG`、`DECIMAL`、`BOOLEAN`、`DATE`、`DATETIME`、`JSON`。

### 4.3 `field_relation`

| 字段 | 类型 | 约束 | 说明 |
|---|---|---|---|
| `relation_id` | BIGINT | 主键 | 关系唯一标识 |
| `relation_name` | VARCHAR(128) | 可空 | 关系业务名称 |
| `source_field_id` | BIGINT | 外键、非空 | 源字段 |
| `target_object_id` | BIGINT | 外键、非空 | 目标对象 |
| `target_field_id` | BIGINT | 外键、非空 | 目标字段 |
| `relation_type` | VARCHAR(32) | 非空 | 源对象到目标对象的关系类型 |
| `description` | VARCHAR(512) | 可空 | 关系语义描述 |
| `created_at` | DATETIME | 非空 | 创建时间 |
| `updated_at` | DATETIME | 非空 | 更新时间 |

约束：

- `source_field_id` 隐式确定源对象，不重复保存 `source_object_id`。
- `target_field_id` 必须属于 `target_object_id`。
- 同一 `source_field_id`、`target_field_id`、`relation_type` 组合唯一。

## 5. API 设计

### 5.1 保存对象完整定义

```http
POST /api/metadata/objects/save
```

请求体示例（修改已有对象）：

```json
{
  "objectId": 1001,
  "objectName": "产品",
  "parentObjectId": 1000,
  "description": "产品对象",
  "fields": [
    {
      "fieldId": 2001,
      "fieldName": "id",
      "fieldType": "STRING",
      "primaryKey": true,
      "description": "产品业务 ID"
    },
    {
      "fieldId": 2002,
      "fieldName": "brand_id",
      "fieldType": "STRING",
      "primaryKey": false,
      "description": "关联品牌 ID"
    }
  ],
  "outgoingRelations": [
    {
      "relationId": 3001,
      "relationName": "所属品牌",
      "sourceFieldName": "brand_id",
      "targetObjectId": 1000,
      "targetFieldId": 2101,
      "relationType": "MANY_TO_ONE",
      "description": "产品所属品牌"
    }
  ]
}
```

保存语义：

- 请求体不包含 `objectId` 时创建新对象，服务端生成 `objectId`。
- 创建时，服务端为所有字段和关系生成 ID；调用方不应提交 `fieldId` 或 `relationId`。
- 请求体包含 `objectId` 时修改已有对象，执行即时全量覆盖。
- 修改时，已有字段或关系携带原 ID；新增字段或关系不携带 ID，由服务端生成。
- 修改时，提交的已有 `fieldId` 和 `relationId` 必须属于当前对象；禁止借此修改其他对象的字段或关系。
- 修改时，请求体中未出现的原字段和原出向关系将被删除。
- 修改只覆盖当前对象发出的关系，不覆盖其他对象指向当前对象的入向关系。
- 保存请求中的出向关系使用 `sourceFieldName` 引用当前请求中的字段；服务端校验字段名并转换为 `source_field_id` 后入库。
- 关系的目标对象和目标字段已经存在，因此请求继续使用 `targetObjectId` 和 `targetFieldId` 引用。
- 创建对象时，关系目标必须是已存在对象的字段；如果需要创建指向自身字段的关系，应先创建对象，再通过修改保存该关系。
- 如果待删除字段仍被其他对象的入向关系引用，则拒绝保存，并返回引用明细。
- 对象、字段和出向关系的保存处于同一个事务中，任何失败均完整回滚。

成功响应：

```json
{
  "objectId": 1001,
  "success": true
}
```

### 5.2 查询单对象完整定义

```http
GET /api/metadata/objects/{objectId}
```

返回：

- 对象基本信息。
- 对象全部字段。
- 对象全部出向关系。
- 其他对象指向该对象的全部入向关系。

### 5.3 查询元数据图

```http
GET /api/metadata/graph?objectIds=1001,1002
```

查询语义：

- 不传 `objectIds`：返回全部对象、全部字段和全部关系。
- 传入一个对象 ID：返回该对象、与其直接相关的全部关系，以及全部直接相邻对象的完整定义。只扩展一层，不递归查询相邻对象的其他关系。
- 传入多个对象 ID：返回指定对象的完整定义，以及源对象和目标对象均处于指定集合中的关系。
- 任一指定对象不存在时，返回 `404 OBJECT_NOT_FOUND`，不返回部分结果。

响应采用适合大模型消费的扁平图结构：

```json
{
  "objects": [],
  "fields": [],
  "relations": []
}
```

## 6. 保存流程

保存对象完整定义时：

1. 判断请求是否包含 `objectId`，确定创建或修改语义。
2. 创建时生成对象 ID；修改时锁定并确认对象存在。
3. 校验对象名称、字段名称、字段类型和唯一主键字段。
4. 修改时校验请求中的已有字段 ID 和关系 ID 均属于当前对象。
5. 按 `sourceFieldName` 解析所有出向关系的源字段，并校验字段属于当前请求中的对象定义。
6. 校验所有关系的目标对象存在，且目标字段属于目标对象。
7. 修改时计算待删除字段，并查询这些字段是否仍被其他对象的入向关系引用。
8. 若存在入向引用，返回 `409 FIELD_REFERENCED` 及引用明细。
9. 删除请求中未出现的原出向关系。
10. 新增或更新请求中的字段和出向关系，并删除未出现且无入向引用的原字段。
11. 提交事务并返回对象 ID。

为了避免关系暂时引用待删除字段，实际数据库写入顺序可在服务内部调整，但最终结果必须符合全量覆盖语义。

## 7. 错误处理

| HTTP 状态 | 错误码 | 场景 |
|---|---|---|
| 400 | `INVALID_DEFINITION` | 主键字段数量错误、字段类型无效、字段或关系 ID 不属于当前对象、源字段不属于当前对象、目标字段与目标对象不匹配 |
| 404 | `OBJECT_NOT_FOUND` | 修改或查询的对象不存在 |
| 404 | `TARGET_NOT_FOUND` | 关系目标对象或目标字段不存在 |
| 409 | `OBJECT_NAME_CONFLICT` | 对象名称重复 |
| 409 | `FIELD_NAME_CONFLICT` | 同一对象内字段名称重复 |
| 409 | `FIELD_REFERENCED` | 待删除字段仍被其他对象的关系引用 |

错误响应统一包含错误码、消息和可选详情：

```json
{
  "code": "FIELD_REFERENCED",
  "message": "待删除字段仍被其他对象关系引用",
  "details": {
    "fieldId": 2002,
    "relationIds": [3004, 3005]
  }
}
```

## 8. 一致性与并发

- 保存操作使用数据库事务。
- 修改已有对象时对对象记录加行锁，串行化同一对象的并发修改。
- 唯一索引保证对象名称、对象内字段名称和关系组合不重复。
- 外键保证对象、字段和关系的基本引用完整性。
- 应用层校验 `target_field_id` 确实属于 `target_object_id`。
- 本期不设计草稿、发布状态或元数据版本。

## 9. 模块边界

- `metadata-api`：Controller、请求响应 DTO、统一异常响应。
- `metadata-application`：保存对象、查询对象、查询元数据图的用例服务。
- `metadata-domain`：对象、字段、关系模型及校验规则。
- `metadata-infrastructure`：MyBatis-Plus Mapper、数据库实体和查询实现。

后续实例与图数据库能力作为独立模块接入，不改变本期元数据 API 的领域语义。

## 10. 测试策略

### 10.1 单元测试

- 对象必须且只能包含一个主键字段。
- 字段名称在对象内唯一。
- 出向关系的 `sourceFieldName` 必须匹配当前对象中的字段。
- 修改请求中的已有字段 ID 和关系 ID 必须属于当前对象。
- 目标字段必须属于目标对象。
- 全量覆盖差异计算正确。
- 入向关系引用明细计算正确。

### 10.2 集成测试

- 创建对象并由服务端生成全部 ID。
- 修改对象并新增、更新、删除字段和出向关系。
- 删除被入向关系引用的字段时返回 `409`，且事务完整回滚。
- 查询单对象时返回字段、入向关系和出向关系。
- 不带条件查询完整元数据图。
- 带单个对象条件时只扩展一层直接相邻对象。
- 带多个对象条件时只返回集合内部关系。
- 并发修改同一对象时不会产生部分覆盖或重复数据。

## 11. 本期排除项

- 实例数据表和实例保存接口。
- Neo4j 节点与边写入。
- Cypher 生成和执行接口。
- 元数据草稿、发布、版本和历史回滚。
- 基于元数据的复杂下钻与笛卡尔积查询。
