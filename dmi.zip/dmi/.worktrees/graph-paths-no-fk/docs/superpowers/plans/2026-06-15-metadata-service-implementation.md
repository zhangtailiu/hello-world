# 元数据服务实现计划

> **面向 AI 代理的工作者：** 必需子技能：使用 superpowers-zh:subagent-driven-development（推荐）或 superpowers-zh:executing-plans 逐任务实现此计划。步骤使用复选框（`- [ ]`）语法来跟踪进度。

**目标：** 构建一个可运行、可通过 Docker MySQL 验证的元数据服务，支持对象完整定义的统一保存、单对象完整查询和条件元数据图查询。

**架构：** 使用单模块 Spring Boot 应用，按 `metadata` 业务能力组织 API、应用服务、领域模型和持久化代码。MySQL 通过 Flyway 建表，MyBatis-Plus 负责基础持久化，复杂关系查询使用专用 Mapper SQL；保存操作在单事务中执行并对修改对象加行锁。

**技术栈：** Java 17、Spring Boot 3、MyBatis-Plus、MySQL 8.4、Flyway、JUnit 5、Testcontainers、Maven、Docker Compose

---

## 文件结构

### 项目与运行配置

- 创建：`pom.xml`，定义 Java 17、Spring Boot、MyBatis-Plus、Flyway、MySQL 和 Testcontainers 依赖。
- 创建：`.gitignore`，忽略 IDE、构建产物和视觉伴侣临时文件。
- 创建：`compose.yaml`，启动本地 MySQL 8.4。
- 创建：`src/main/resources/application.yml`，定义数据库连接和 MyBatis 配置。
- 创建：`src/main/resources/db/migration/V1__create_metadata_tables.sql`，创建三张元数据表及索引。
- 创建：`src/main/java/com/example/dmi/DmiApplication.java`，应用入口。
- 创建：`src/test/java/com/example/dmi/support/MySqlIntegrationTest.java`，共享 Testcontainers MySQL 配置。

### 元数据模型与持久化

- 创建：`src/main/java/com/example/dmi/metadata/model/FieldType.java`
- 创建：`src/main/java/com/example/dmi/metadata/model/RelationType.java`
- 创建：`src/main/java/com/example/dmi/metadata/persistence/entity/ObjectDefinitionEntity.java`
- 创建：`src/main/java/com/example/dmi/metadata/persistence/entity/ObjectFieldEntity.java`
- 创建：`src/main/java/com/example/dmi/metadata/persistence/entity/FieldRelationEntity.java`
- 创建：`src/main/java/com/example/dmi/metadata/persistence/mapper/ObjectDefinitionMapper.java`
- 创建：`src/main/java/com/example/dmi/metadata/persistence/mapper/ObjectFieldMapper.java`
- 创建：`src/main/java/com/example/dmi/metadata/persistence/mapper/FieldRelationMapper.java`
- 创建：`src/main/resources/mapper/ObjectDefinitionMapper.xml`
- 创建：`src/main/resources/mapper/FieldRelationMapper.xml`

### 保存对象能力

- 创建：`src/main/java/com/example/dmi/metadata/api/dto/SaveObjectRequest.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/SaveFieldRequest.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/SaveRelationRequest.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/SaveObjectResponse.java`
- 创建：`src/main/java/com/example/dmi/metadata/application/MetadataDefinitionValidator.java`
- 创建：`src/main/java/com/example/dmi/metadata/application/MetadataSaveService.java`

### 查询与 API

- 创建：`src/main/java/com/example/dmi/metadata/api/dto/ObjectDefinitionResponse.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/ObjectSummaryResponse.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/FieldResponse.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/RelationResponse.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/MetadataGraphResponse.java`
- 创建：`src/main/java/com/example/dmi/metadata/application/MetadataQueryService.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/MetadataController.java`
- 创建：`src/main/java/com/example/dmi/common/api/ApiError.java`
- 创建：`src/main/java/com/example/dmi/common/api/GlobalExceptionHandler.java`
- 创建：`src/main/java/com/example/dmi/common/error/MetadataException.java`
- 创建：`src/main/java/com/example/dmi/common/error/ErrorCode.java`

### 测试与文档

- 创建：`src/test/java/com/example/dmi/DmiApplicationTest.java`
- 创建：`src/test/java/com/example/dmi/metadata/application/MetadataDefinitionValidatorTest.java`
- 创建：`src/test/java/com/example/dmi/metadata/application/MetadataSaveServiceIntegrationTest.java`
- 创建：`src/test/java/com/example/dmi/metadata/application/MetadataQueryServiceIntegrationTest.java`
- 创建：`src/test/java/com/example/dmi/metadata/api/MetadataControllerIntegrationTest.java`
- 创建：`README.md`，记录启动、接口和验证命令。

---

### 任务 1：初始化可运行项目与数据库结构

**文件：**
- 创建：`.gitignore`
- 创建：`pom.xml`
- 创建：`compose.yaml`
- 创建：`src/main/java/com/example/dmi/DmiApplication.java`
- 创建：`src/main/resources/application.yml`
- 创建：`src/main/resources/db/migration/V1__create_metadata_tables.sql`
- 创建：`src/test/java/com/example/dmi/support/MySqlIntegrationTest.java`
- 创建：`src/test/java/com/example/dmi/DmiApplicationTest.java`

- [ ] **步骤 1：初始化 Git 仓库并添加忽略规则**

运行：

```bash
git init
```

`.gitignore`：

```gitignore
target/
.idea/
*.iml
.DS_Store
.superpowers/
```

- [ ] **步骤 2：创建 Maven 工程配置**

`pom.xml` 必须包含：

```xml
<properties>
    <java.version>17</java.version>
    <mybatis-plus.version>3.5.12</mybatis-plus.version>
    <testcontainers.version>1.21.3</testcontainers.version>
</properties>

<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-validation</artifactId>
    </dependency>
    <dependency>
        <groupId>com.baomidou</groupId>
        <artifactId>mybatis-plus-spring-boot3-starter</artifactId>
        <version>${mybatis-plus.version}</version>
    </dependency>
    <dependency>
        <groupId>org.flywaydb</groupId>
        <artifactId>flyway-core</artifactId>
    </dependency>
    <dependency>
        <groupId>org.flywaydb</groupId>
        <artifactId>flyway-mysql</artifactId>
    </dependency>
    <dependency>
        <groupId>com.mysql</groupId>
        <artifactId>mysql-connector-j</artifactId>
        <scope>runtime</scope>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-testcontainers</artifactId>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.testcontainers</groupId>
        <artifactId>mysql</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```

使用 Spring Boot `3.5.7` 的 parent 和 Spring Boot Maven Plugin，并配置 `maven.compiler.release=17`。

- [ ] **步骤 3：创建应用入口和运行配置**

`DmiApplication.java`：

```java
@SpringBootApplication
@MapperScan("com.example.dmi.metadata.persistence.mapper")
public class DmiApplication {
    public static void main(String[] args) {
        SpringApplication.run(DmiApplication.class, args);
    }
}
```

`application.yml`：

```yaml
spring:
  datasource:
    url: ${DB_URL:jdbc:mysql://localhost:3306/dmi?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC}
    username: ${DB_USERNAME:dmi}
    password: ${DB_PASSWORD:dmi}
  flyway:
    enabled: true
mybatis-plus:
  configuration:
    map-underscore-to-camel-case: true
```

- [ ] **步骤 4：创建数据库迁移**

`V1__create_metadata_tables.sql` 创建：

```sql
CREATE TABLE object_definition (
    object_id BIGINT NOT NULL PRIMARY KEY,
    object_name VARCHAR(128) NOT NULL,
    parent_object_id BIGINT NULL,
    description VARCHAR(512) NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    CONSTRAINT uk_object_definition_name UNIQUE (object_name),
    CONSTRAINT fk_object_parent FOREIGN KEY (parent_object_id)
        REFERENCES object_definition (object_id)
);

CREATE TABLE object_field (
    field_id BIGINT NOT NULL PRIMARY KEY,
    object_id BIGINT NOT NULL,
    field_name VARCHAR(128) NOT NULL,
    field_type VARCHAR(32) NOT NULL,
    is_primary_key BOOLEAN NOT NULL,
    description VARCHAR(512) NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    CONSTRAINT uk_object_field_name UNIQUE (object_id, field_name),
    CONSTRAINT fk_field_object FOREIGN KEY (object_id)
        REFERENCES object_definition (object_id)
);

CREATE TABLE field_relation (
    relation_id BIGINT NOT NULL PRIMARY KEY,
    relation_name VARCHAR(128) NULL,
    source_field_id BIGINT NOT NULL,
    target_object_id BIGINT NOT NULL,
    target_field_id BIGINT NOT NULL,
    relation_type VARCHAR(32) NOT NULL,
    description VARCHAR(512) NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    CONSTRAINT uk_field_relation UNIQUE (source_field_id, target_field_id, relation_type),
    CONSTRAINT fk_relation_source_field FOREIGN KEY (source_field_id)
        REFERENCES object_field (field_id),
    CONSTRAINT fk_relation_target_object FOREIGN KEY (target_object_id)
        REFERENCES object_definition (object_id),
    CONSTRAINT fk_relation_target_field FOREIGN KEY (target_field_id)
        REFERENCES object_field (field_id)
);
```

同时为 `object_field.object_id`、`field_relation.target_object_id`、`field_relation.target_field_id` 建普通索引。

- [ ] **步骤 5：编写启动失败测试**

`DmiApplicationTest` 继承 `MySqlIntegrationTest`：

```java
@SpringBootTest
class DmiApplicationTest extends MySqlIntegrationTest {
    @Test
    void contextLoads() {
    }
}
```

`MySqlIntegrationTest` 使用：

```java
@Testcontainers
public abstract class MySqlIntegrationTest {
    @Container
    @ServiceConnection
    static final MySQLContainer<?> MYSQL =
        new MySQLContainer<>("mysql:8.4");
}
```

- [ ] **步骤 6：运行测试并修复项目装配**

运行：

```bash
mvn test -Dtest=DmiApplicationTest
```

预期：测试通过，Flyway 成功创建三张表。

- [ ] **步骤 7：添加本地 MySQL Compose 配置**

`compose.yaml`：

```yaml
services:
  mysql:
    image: mysql:8.4
    environment:
      MYSQL_DATABASE: dmi
      MYSQL_USER: dmi
      MYSQL_PASSWORD: dmi
      MYSQL_ROOT_PASSWORD: root
    ports:
      - "3306:3306"
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost", "-uroot", "-proot"]
      interval: 3s
      timeout: 3s
      retries: 20
```

- [ ] **步骤 8：Commit**

```bash
git add .gitignore pom.xml compose.yaml src/main src/test docs/superpowers
git commit -m "chore: initialize metadata service"
```

---

### 任务 2：实现持久化实体、枚举和 Mapper

**文件：**
- 创建：`src/main/java/com/example/dmi/metadata/model/FieldType.java`
- 创建：`src/main/java/com/example/dmi/metadata/model/RelationType.java`
- 创建：`src/main/java/com/example/dmi/metadata/persistence/entity/ObjectDefinitionEntity.java`
- 创建：`src/main/java/com/example/dmi/metadata/persistence/entity/ObjectFieldEntity.java`
- 创建：`src/main/java/com/example/dmi/metadata/persistence/entity/FieldRelationEntity.java`
- 创建：`src/main/java/com/example/dmi/metadata/persistence/mapper/ObjectDefinitionMapper.java`
- 创建：`src/main/java/com/example/dmi/metadata/persistence/mapper/ObjectFieldMapper.java`
- 创建：`src/main/java/com/example/dmi/metadata/persistence/mapper/FieldRelationMapper.java`
- 创建：`src/main/resources/mapper/ObjectDefinitionMapper.xml`
- 创建：`src/main/resources/mapper/FieldRelationMapper.xml`
- 测试：`src/test/java/com/example/dmi/metadata/persistence/MetadataMapperIntegrationTest.java`

- [ ] **步骤 1：编写 Mapper 失败测试**

测试插入对象和字段，然后断言：

```java
assertThat(objectDefinitionMapper.selectById(objectId).getObjectName())
    .isEqualTo("品牌");
assertThat(objectFieldMapper.selectList(
    Wrappers.<ObjectFieldEntity>lambdaQuery().eq(ObjectFieldEntity::getObjectId, objectId)))
    .hasSize(1);
```

另一个测试插入产品到品牌的关系，并断言按源对象、目标对象均能查到。

- [ ] **步骤 2：运行测试验证失败**

```bash
mvn test -Dtest=MetadataMapperIntegrationTest
```

预期：FAIL，实体和 Mapper 尚不存在。

- [ ] **步骤 3：实现枚举与实体**

枚举：

```java
public enum FieldType {
    STRING, INTEGER, LONG, DECIMAL, BOOLEAN, DATE, DATETIME, JSON
}

public enum RelationType {
    ONE_TO_ONE, ONE_TO_MANY, MANY_TO_ONE, MANY_TO_MANY
}
```

每个实体使用 `@TableName`、`@TableId(type = IdType.ASSIGN_ID)`，时间字段由服务显式赋值。实体只承载数据库字段，不放业务校验。

- [ ] **步骤 4：实现 Mapper 和专用查询**

基础 Mapper 继承 `BaseMapper<T>`。专用方法：

```java
ObjectDefinitionEntity selectByIdForUpdate(@Param("objectId") long objectId);

List<FieldRelationEntity> selectBySourceObjectId(@Param("objectId") long objectId);

List<FieldRelationEntity> selectByTargetObjectId(@Param("objectId") long objectId);

List<FieldRelationEntity> selectReferencingFields(@Param("fieldIds") Collection<Long> fieldIds);
```

XML 中通过 `field_relation` 连接 `object_field` 确定源对象；`selectByIdForUpdate` 使用 `FOR UPDATE`。

- [ ] **步骤 5：运行 Mapper 集成测试**

```bash
mvn test -Dtest=MetadataMapperIntegrationTest
```

预期：PASS。

- [ ] **步骤 6：Commit**

```bash
git add src/main/java/com/example/dmi/metadata/model \
  src/main/java/com/example/dmi/metadata/persistence \
  src/main/resources/mapper \
  src/test/java/com/example/dmi/metadata/persistence
git commit -m "feat: add metadata persistence model"
```

---

### 任务 3：实现保存请求模型与定义校验

**文件：**
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/SaveObjectRequest.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/SaveFieldRequest.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/SaveRelationRequest.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/SaveObjectResponse.java`
- 创建：`src/main/java/com/example/dmi/common/error/ErrorCode.java`
- 创建：`src/main/java/com/example/dmi/common/error/MetadataException.java`
- 创建：`src/main/java/com/example/dmi/metadata/application/MetadataDefinitionValidator.java`
- 测试：`src/test/java/com/example/dmi/metadata/application/MetadataDefinitionValidatorTest.java`

- [ ] **步骤 1：编写定义校验失败测试**

覆盖以下测试：

```java
assertThatThrownBy(() -> validator.validate(requestWithNoPrimaryKey()))
    .isInstanceOf(MetadataException.class)
    .extracting("code")
    .isEqualTo(ErrorCode.INVALID_DEFINITION);
```

还需覆盖两个主键、重复字段名、关系源字段名不存在、重复关系定义。

- [ ] **步骤 2：运行测试验证失败**

```bash
mvn test -Dtest=MetadataDefinitionValidatorTest
```

预期：FAIL，校验器和 DTO 尚不存在。

- [ ] **步骤 3：实现保存 DTO**

DTO 使用 Java record：

```java
public record SaveObjectRequest(
    Long objectId,
    @NotBlank String objectName,
    Long parentObjectId,
    String description,
    @NotEmpty List<@Valid SaveFieldRequest> fields,
    @NotNull List<@Valid SaveRelationRequest> outgoingRelations
) {}

public record SaveFieldRequest(
    Long fieldId,
    @NotBlank String fieldName,
    @NotNull FieldType fieldType,
    boolean primaryKey,
    String description
) {}

public record SaveRelationRequest(
    Long relationId,
    String relationName,
    @NotBlank String sourceFieldName,
    @NotNull Long targetObjectId,
    @NotNull Long targetFieldId,
    @NotNull RelationType relationType,
    String description
) {}
```

- [ ] **步骤 4：实现领域校验器**

`MetadataDefinitionValidator.validate(request)` 必须：

- 恰好一个主键字段。
- 字段名在请求内唯一。
- 每个 `sourceFieldName` 匹配请求字段。
- `(sourceFieldName, targetFieldId, relationType)` 在请求内唯一。

违反规则时抛出：

```java
throw new MetadataException(ErrorCode.INVALID_DEFINITION, message, details);
```

`ErrorCode` 明确携带 HTTP 状态：

```java
public enum ErrorCode {
    INVALID_DEFINITION(HttpStatus.BAD_REQUEST),
    OBJECT_NOT_FOUND(HttpStatus.NOT_FOUND),
    TARGET_NOT_FOUND(HttpStatus.NOT_FOUND),
    OBJECT_NAME_CONFLICT(HttpStatus.CONFLICT),
    FIELD_NAME_CONFLICT(HttpStatus.CONFLICT),
    FIELD_REFERENCED(HttpStatus.CONFLICT);

    private final HttpStatus status;

    ErrorCode(HttpStatus status) {
        this.status = status;
    }

    public HttpStatus status() {
        return status;
    }
}
```

- [ ] **步骤 5：运行校验器测试**

```bash
mvn test -Dtest=MetadataDefinitionValidatorTest
```

预期：PASS。

- [ ] **步骤 6：Commit**

```bash
git add src/main/java/com/example/dmi/metadata/api/dto \
  src/main/java/com/example/dmi/common/error \
  src/main/java/com/example/dmi/metadata/application/MetadataDefinitionValidator.java \
  src/test/java/com/example/dmi/metadata/application/MetadataDefinitionValidatorTest.java
git commit -m "feat: validate metadata definitions"
```

---

### 任务 4：实现对象创建保存

**文件：**
- 创建：`src/main/java/com/example/dmi/metadata/application/MetadataSaveService.java`
- 测试：`src/test/java/com/example/dmi/metadata/application/MetadataSaveServiceIntegrationTest.java`

- [ ] **步骤 1：编写创建保存失败测试**

构造品牌对象请求，不传任何 ID：

```java
SaveObjectResponse response = service.save(brandRequest);

assertThat(response.objectId()).isNotNull();
assertThat(objectDefinitionMapper.selectById(response.objectId())).isNotNull();
assertThat(fieldsOf(response.objectId()))
    .extracting(ObjectFieldEntity::getFieldName)
    .containsExactlyInAnyOrder("id", "name");
```

再先创建品牌，然后创建产品并通过 `sourceFieldName=brand_id` 关联品牌 `id` 字段，断言关系落库时已转换为产品 `brand_id` 的 `source_field_id`。

- [ ] **步骤 2：运行测试验证失败**

```bash
mvn test -Dtest=MetadataSaveServiceIntegrationTest#createsObjectAndResolvesSourceFieldName
```

预期：FAIL，保存服务尚不存在。

- [ ] **步骤 3：实现创建流程**

`MetadataSaveService.save` 使用 `@Transactional`，当 `objectId == null` 时：

1. 调用定义校验器。
2. 校验父对象存在。
3. 校验所有目标对象和目标字段存在且匹配。
4. 注入 MyBatis-Plus `IdentifierGenerator`，调用 `nextId(entity).longValue()` 生成对象、字段和关系 ID。
5. 先插入对象和字段，建立 `fieldName -> fieldId` 映射。
6. 使用映射解析关系并插入。
7. 返回 `new SaveObjectResponse(objectId, true)`。

目标字段匹配校验必须读取字段并比较：

```java
if (!targetField.getObjectId().equals(relation.targetObjectId())) {
    throw new MetadataException(
        ErrorCode.INVALID_DEFINITION,
        "目标字段不属于目标对象",
        Map.of("targetObjectId", relation.targetObjectId(),
               "targetFieldId", relation.targetFieldId()));
}
```

- [ ] **步骤 4：运行创建保存测试**

```bash
mvn test -Dtest=MetadataSaveServiceIntegrationTest#createsObjectAndResolvesSourceFieldName
```

预期：PASS。

- [ ] **步骤 5：增加创建失败回滚测试**

提交目标字段不属于目标对象的产品定义，断言返回异常后对象、字段和关系均未落库。

- [ ] **步骤 6：运行保存服务测试**

```bash
mvn test -Dtest=MetadataSaveServiceIntegrationTest
```

预期：PASS。

- [ ] **步骤 7：Commit**

```bash
git add src/main/java/com/example/dmi/metadata/application/MetadataSaveService.java \
  src/test/java/com/example/dmi/metadata/application/MetadataSaveServiceIntegrationTest.java
git commit -m "feat: create complete object definitions"
```

---

### 任务 5：实现对象全量覆盖修改与引用冲突保护

**文件：**
- 修改：`src/main/java/com/example/dmi/metadata/application/MetadataSaveService.java`
- 修改：`src/main/java/com/example/dmi/metadata/persistence/mapper/ObjectDefinitionMapper.java`
- 修改：`src/main/java/com/example/dmi/metadata/persistence/mapper/FieldRelationMapper.java`
- 修改：`src/main/resources/mapper/ObjectDefinitionMapper.xml`
- 修改：`src/main/resources/mapper/FieldRelationMapper.xml`
- 测试：`src/test/java/com/example/dmi/metadata/application/MetadataSaveServiceIntegrationTest.java`

- [ ] **步骤 1：编写全量覆盖失败测试**

创建产品后提交包含同一 `objectId` 的修改请求：

- 保留并改名已有字段。
- 新增字段。
- 删除一个未被引用字段。
- 删除旧出向关系并新增另一个出向关系。

断言数据库最终状态严格等于新请求。

- [ ] **步骤 2：编写入向引用冲突失败测试**

创建品牌、产品和产品到品牌的关系，然后尝试删除品牌被引用的 `id` 字段：

```java
assertThatThrownBy(() -> service.save(brandWithoutIdField))
    .isInstanceOf(MetadataException.class)
    .extracting("code")
    .isEqualTo(ErrorCode.FIELD_REFERENCED);
```

断言品牌原字段仍完整存在，证明事务回滚。

- [ ] **步骤 3：运行测试验证失败**

```bash
mvn test -Dtest=MetadataSaveServiceIntegrationTest
```

预期：新增修改场景 FAIL。

- [ ] **步骤 4：实现修改流程**

当 `objectId != null` 时：

1. `selectByIdForUpdate(objectId)` 锁定对象，不存在则抛 `OBJECT_NOT_FOUND`。
2. 校验请求中的已有 `fieldId` 属于当前对象。
3. 校验请求中的已有 `relationId` 的源字段属于当前对象。
4. 计算原字段 ID 减去请求保留字段 ID 得到待删除字段。
5. 查询待删除字段的入向关系；排除当前对象将在本次覆盖中删除的出向关系。
6. 仍有引用时抛 `FIELD_REFERENCED`，详情包含字段和关系 ID。
7. 删除当前对象全部原出向关系。
8. 新增或更新字段，删除无引用的待删除字段。
9. 使用最新字段名到 ID 映射重建全部出向关系；请求携带的原 `relationId` 保持不变，新增关系生成新 ID。
10. 更新对象基本信息。

- [ ] **步骤 5：运行修改与回滚测试**

```bash
mvn test -Dtest=MetadataSaveServiceIntegrationTest
```

预期：PASS。

- [ ] **步骤 6：Commit**

```bash
git add src/main/java/com/example/dmi/metadata/application/MetadataSaveService.java \
  src/main/java/com/example/dmi/metadata/persistence \
  src/main/resources/mapper \
  src/test/java/com/example/dmi/metadata/application/MetadataSaveServiceIntegrationTest.java
git commit -m "feat: replace object definitions atomically"
```

---

### 任务 6：实现单对象完整定义查询

**文件：**
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/ObjectDefinitionResponse.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/ObjectSummaryResponse.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/FieldResponse.java`
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/RelationResponse.java`
- 创建：`src/main/java/com/example/dmi/metadata/application/MetadataQueryService.java`
- 测试：`src/test/java/com/example/dmi/metadata/application/MetadataQueryServiceIntegrationTest.java`

- [ ] **步骤 1：编写单对象查询失败测试**

创建品牌和产品关系，查询品牌后断言：

```java
ObjectDefinitionResponse brand = queryService.getObject(brandId);

assertThat(brand.fields()).hasSize(2);
assertThat(brand.outgoingRelations()).isEmpty();
assertThat(brand.incomingRelations())
    .extracting(RelationResponse::relationName)
    .containsExactly("所属品牌");
```

查询不存在对象时断言 `OBJECT_NOT_FOUND`。

- [ ] **步骤 2：运行测试验证失败**

```bash
mvn test -Dtest=MetadataQueryServiceIntegrationTest#getObjectReturnsFieldsAndBothRelationDirections
```

预期：FAIL，查询服务尚不存在。

- [ ] **步骤 3：实现响应 DTO 和查询服务**

响应 DTO 使用 record，并明确关系中包含源与目标对象/字段标识：

```java
public record ObjectSummaryResponse(
    Long objectId,
    String objectName,
    Long parentObjectId,
    String description
) {}

public record RelationResponse(
    Long relationId,
    String relationName,
    Long sourceObjectId,
    Long sourceFieldId,
    Long targetObjectId,
    Long targetFieldId,
    RelationType relationType,
    String description
) {}
```

`getObject(objectId)` 分别读取对象、字段、出向关系和入向关系并组装；不存在时抛 `OBJECT_NOT_FOUND`。

- [ ] **步骤 4：运行单对象查询测试**

```bash
mvn test -Dtest=MetadataQueryServiceIntegrationTest#getObjectReturnsFieldsAndBothRelationDirections
```

预期：PASS。

- [ ] **步骤 5：Commit**

```bash
git add src/main/java/com/example/dmi/metadata/api/dto \
  src/main/java/com/example/dmi/metadata/application/MetadataQueryService.java \
  src/test/java/com/example/dmi/metadata/application/MetadataQueryServiceIntegrationTest.java
git commit -m "feat: query complete object definitions"
```

---

### 任务 7：实现条件元数据图查询

**文件：**
- 创建：`src/main/java/com/example/dmi/metadata/api/dto/MetadataGraphResponse.java`
- 修改：`src/main/java/com/example/dmi/metadata/application/MetadataQueryService.java`
- 修改：`src/main/java/com/example/dmi/metadata/persistence/mapper/FieldRelationMapper.java`
- 修改：`src/main/resources/mapper/FieldRelationMapper.xml`
- 测试：`src/test/java/com/example/dmi/metadata/application/MetadataQueryServiceIntegrationTest.java`

- [ ] **步骤 1：编写三种图查询失败测试**

创建品牌、产品、系列和省对象及关系，覆盖：

1. `getGraph(emptyList())` 返回全部对象、字段和关系。
2. `getGraph(List.of(productId))` 返回产品、品牌、系列完整定义及产品直接相关关系，不返回省。
3. `getGraph(List.of(productId, brandId))` 仅返回产品、品牌及二者之间关系，不返回系列。

- [ ] **步骤 2：运行测试验证失败**

```bash
mvn test -Dtest=MetadataQueryServiceIntegrationTest
```

预期：图查询场景 FAIL。

- [ ] **步骤 3：实现图查询 Mapper**

提供：

```java
List<FieldRelationEntity> selectAllRelations();
List<FieldRelationEntity> selectRelationsTouchingObject(@Param("objectId") long objectId);
List<FieldRelationEntity> selectRelationsWithinObjects(@Param("objectIds") Collection<Long> objectIds);
```

`selectRelationsWithinObjects` 必须通过源字段连接源对象，并同时约束源对象与目标对象均在集合中。

- [ ] **步骤 4：实现图查询服务**

`MetadataGraphResponse`：

```java
public record MetadataGraphResponse(
    List<ObjectSummaryResponse> objects,
    List<FieldResponse> fields,
    List<RelationResponse> relations
) {}
```

服务规则：

- 空集合：查询全部。
- 一个 ID：查询触达该对象的关系，从关系中收集相邻对象 ID，加上查询对象 ID，再批量查询完整对象与字段。
- 多个 ID：先确认所有对象存在，再只查询集合内部关系和指定对象字段。
- 所有数组按 ID 升序返回，保证响应稳定、测试可重复。

- [ ] **步骤 5：运行图查询测试**

```bash
mvn test -Dtest=MetadataQueryServiceIntegrationTest
```

预期：PASS。

- [ ] **步骤 6：Commit**

```bash
git add src/main/java/com/example/dmi/metadata/api/dto/MetadataGraphResponse.java \
  src/main/java/com/example/dmi/metadata/application/MetadataQueryService.java \
  src/main/java/com/example/dmi/metadata/persistence/mapper/FieldRelationMapper.java \
  src/main/resources/mapper/FieldRelationMapper.xml \
  src/test/java/com/example/dmi/metadata/application/MetadataQueryServiceIntegrationTest.java
git commit -m "feat: query filtered metadata graphs"
```

---

### 任务 8：暴露 REST API 与统一错误响应

**文件：**
- 创建：`src/main/java/com/example/dmi/metadata/api/MetadataController.java`
- 创建：`src/main/java/com/example/dmi/common/api/ApiError.java`
- 创建：`src/main/java/com/example/dmi/common/api/GlobalExceptionHandler.java`
- 测试：`src/test/java/com/example/dmi/metadata/api/MetadataControllerIntegrationTest.java`

- [ ] **步骤 1：编写 API 失败测试**

使用 `MockMvc` 覆盖：

```java
mockMvc.perform(post("/api/metadata/objects/save")
        .contentType(MediaType.APPLICATION_JSON)
        .content(validBrandJson))
    .andExpect(status().isOk())
    .andExpect(jsonPath("$.success").value(true))
    .andExpect(jsonPath("$.objectId").isNumber());
```

还需覆盖：

- 携带 `objectId` 修改。
- `GET /api/metadata/objects/{objectId}`。
- `GET /api/metadata/graph`。
- `GET /api/metadata/graph?objectIds=id1,id2`。
- 无主键字段返回 `400 INVALID_DEFINITION`。
- 删除被引用字段返回 `409 FIELD_REFERENCED`。
- 查询不存在对象返回 `404 OBJECT_NOT_FOUND`。

- [ ] **步骤 2：运行 API 测试验证失败**

```bash
mvn test -Dtest=MetadataControllerIntegrationTest
```

预期：FAIL，Controller 尚不存在。

- [ ] **步骤 3：实现 Controller**

```java
@RestController
@RequestMapping("/api/metadata")
public class MetadataController {
    private final MetadataSaveService saveService;
    private final MetadataQueryService queryService;

    @PostMapping("/objects/save")
    public SaveObjectResponse save(@Valid @RequestBody SaveObjectRequest request) {
        return saveService.save(request);
    }

    @GetMapping("/objects/{objectId}")
    public ObjectDefinitionResponse getObject(@PathVariable Long objectId) {
        return queryService.getObject(objectId);
    }

    @GetMapping("/graph")
    public MetadataGraphResponse getGraph(
        @RequestParam(required = false) List<Long> objectIds) {
        return queryService.getGraph(objectIds == null ? List.of() : objectIds);
    }
}
```

- [ ] **步骤 4：实现统一异常响应**

`ApiError`：

```java
public record ApiError(String code, String message, Object details) {}
```

`GlobalExceptionHandler` 将 `MetadataException` 映射到错误码指定的 HTTP 状态；将 Bean Validation 错误映射为 `400 INVALID_DEFINITION`；将唯一索引冲突映射为对应 `409` 错误。

- [ ] **步骤 5：运行 API 集成测试**

```bash
mvn test -Dtest=MetadataControllerIntegrationTest
```

预期：PASS。

- [ ] **步骤 6：运行全部自动化测试**

```bash
mvn clean test
```

预期：BUILD SUCCESS，全部测试通过。

- [ ] **步骤 7：Commit**

```bash
git add src/main/java/com/example/dmi/metadata/api/MetadataController.java \
  src/main/java/com/example/dmi/common/api \
  src/test/java/com/example/dmi/metadata/api
git commit -m "feat: expose metadata REST API"
```

---

### 任务 9：使用本地 Docker MySQL 做真实 HTTP 验证

**文件：**
- 创建：`README.md`
- 创建：`scripts/verify-api.sh`

- [ ] **步骤 1：编写真实接口验证脚本**

`scripts/verify-api.sh` 使用 `curl` 和 `jq`：

1. 创建品牌对象并提取 `brandObjectId`。
2. 查询品牌详情，提取品牌 `id` 字段的 `fieldId`。
3. 创建产品对象，通过 `sourceFieldName=brand_id` 关联品牌字段。
4. 查询产品详情，断言存在出向关系。
5. 查询 `graph?objectIds=$brandObjectId`，断言返回品牌和产品。
6. 查询 `graph?objectIds=$brandObjectId,$productObjectId`，断言仅返回二者及内部关系。
7. 尝试删除品牌被引用字段，断言 HTTP `409` 和 `FIELD_REFERENCED`。

脚本开头必须使用：

```bash
#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${BASE_URL:-http://localhost:8080}"
```

- [ ] **步骤 2：记录启动与验证文档**

`README.md` 包含：

```bash
docker compose up -d
mvn spring-boot:run
./scripts/verify-api.sh
```

同时记录统一保存接口的创建/修改语义，以及三种图查询行为。

- [ ] **步骤 3：启动 MySQL 并确认健康**

```bash
docker compose up -d
docker compose ps
```

预期：`mysql` 状态为 healthy。

- [ ] **步骤 4：启动应用**

```bash
mvn spring-boot:run
```

预期：应用监听 `8080`，Flyway 迁移成功。

- [ ] **步骤 5：运行真实 HTTP 验证**

在另一个终端运行：

```bash
chmod +x scripts/verify-api.sh
./scripts/verify-api.sh
```

预期：脚本退出码为 `0`，输出每个验证步骤通过。

- [ ] **步骤 6：停止应用和 Docker 服务**

停止 Spring Boot 进程，然后运行：

```bash
docker compose down -v
```

- [ ] **步骤 7：运行最终验证**

```bash
mvn clean test
git status --short
```

预期：测试全部通过；Git 只显示本任务待提交文件。

- [ ] **步骤 8：Commit**

```bash
git add README.md scripts/verify-api.sh
git commit -m "docs: add metadata API verification workflow"
```

---

## 最终验收标准

- `POST /api/metadata/objects/save` 在无 `objectId` 时创建对象并返回生成的 ID。
- 同一接口在有 `objectId` 时即时全量覆盖对象字段与出向关系。
- 保存关系时可用 `sourceFieldName` 引用同一请求中的新字段。
- 删除仍被其他对象入向关系引用的字段时返回 `409 FIELD_REFERENCED`，且事务完整回滚。
- 单对象查询返回对象字段、入向关系和出向关系。
- 元数据图不传条件时返回全量数据；传一个对象时扩展一层；传多个对象时仅返回集合内部关系。
- `mvn clean test` 通过。
- 使用 Docker MySQL 启动应用后，`scripts/verify-api.sh` 真实 HTTP 验证通过。
