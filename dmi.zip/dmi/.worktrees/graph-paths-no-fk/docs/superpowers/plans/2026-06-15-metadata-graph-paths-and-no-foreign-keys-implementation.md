# 元数据最短路径、无外键与注释增强实现计划

> **面向 AI 代理的工作者：** 必需子技能：使用 superpowers:subagent-driven-development（推荐）或 superpowers:executing-plans 逐任务实现此计划。步骤使用复选框（`- [ ]`）语法来跟踪进度。

**目标：** 让多对象 `/graph` 查询返回所有最短路径上的完整元数据，移除 MySQL 外键并补充公共代码与数据库字段中文注释。

**架构：** 新增纯内存 `MetadataGraphPathFinder`，通过无向 BFS 找到每对指定对象之间所有最短路径边的并集；`MetadataQueryService` 仅负责加载和组装响应。直接修改初始 Flyway 建表脚本为无外键结构，并提供一次性数据重建脚本；数据引用完整性继续由 `MetadataSaveService` 校验。

**技术栈：** Java 17、Spring Boot、MyBatis-Plus、MySQL 8、Flyway、JUnit 5、AssertJ、Testcontainers

---

### 任务 1：实现所有最短路径图算法

**文件：**
- 创建：`src/main/java/com/example/dmi/metadata/application/MetadataGraphPathFinder.java`
- 创建：`src/test/java/com/example/dmi/metadata/application/MetadataGraphPathFinderTest.java`

- [ ] **步骤 1：编写失败的路径算法测试**

创建测试，使用对象边 `series-product`、`product-brand`、`product-category`、`category-brand`，验证：

```java
Set<Long> relationIds = pathFinder.findAllShortestPathRelationIds(
    Set.of(brandId, seriesId), relations, fieldsById);

assertThat(relationIds).containsExactlyInAnyOrder(
    seriesToProductId, productToBrandId);
```

同时添加以下独立测试：

- 反向遍历可找到品牌到系列路径。
- 两条等长最短路径时返回两条路径上的全部关系。
- 无路径时返回空集合。
- 环存在时不会包含更长绕路关系。

- [ ] **步骤 2：运行测试并确认因类不存在而失败**

运行：

```bash
mvn -Dtest=MetadataGraphPathFinderTest test
```

预期：FAIL，`MetadataGraphPathFinder` 不存在。

- [ ] **步骤 3：实现最小无向 BFS 算法**

实现：

```java
public Set<Long> findAllShortestPathRelationIds(
    Set<Long> requestedObjectIds,
    List<FieldRelationEntity> relations,
    Map<Long, ObjectFieldEntity> fieldsById)
```

构建双向邻接表；对每一对请求对象执行 BFS 计算距离；从终点沿距离递减的边回溯并收集全部最短路径关系 ID。忽略源字段不存在的损坏关系，避免查询接口空指针。

- [ ] **步骤 4：运行路径算法测试**

运行：

```bash
mvn -Dtest=MetadataGraphPathFinderTest test
```

预期：全部 PASS。

- [ ] **步骤 5：提交**

```bash
git add src/main/java/com/example/dmi/metadata/application/MetadataGraphPathFinder.java \
  src/test/java/com/example/dmi/metadata/application/MetadataGraphPathFinderTest.java
git commit -m "feat: find all shortest metadata paths"
```

### 任务 2：将多对象 `/graph` 接入最短路径

**文件：**
- 修改：`src/main/java/com/example/dmi/metadata/application/MetadataQueryService.java`
- 修改：`src/test/java/com/example/dmi/metadata/application/MetadataQueryServiceIntegrationTest.java`
- 修改：`src/test/java/com/example/dmi/metadata/api/MetadataControllerIntegrationTest.java`

- [ ] **步骤 1：修改集成测试表达新行为**

将品牌与系列查询断言修改为：

```java
MetadataGraphResponse selected = queryService.getGraph(List.of(brandId, seriesId));
assertThat(selected.objects()).extracting("objectId")
    .containsExactlyInAnyOrder(brandId, productId, seriesId);
assertThat(selected.relations()).hasSize(2);
```

增加两个无关联对象查询测试，验证两个指定对象仍返回但关系为空。增加 Controller 测试，验证 HTTP `/graph?objectIds=<brand>,<series>` 包含中间产品。

- [ ] **步骤 2：运行集成测试并确认失败**

运行：

```bash
TESTCONTAINERS_RYUK_DISABLED=true DOCKER_AUTH_CONFIG='{}' \
  mvn -Dtest=MetadataQueryServiceIntegrationTest,MetadataControllerIntegrationTest test
```

预期：品牌与系列查询缺少产品及关系。

- [ ] **步骤 3：接入路径查找器**

向 `MetadataQueryService` 注入 `MetadataGraphPathFinder`。多对象查询时：

```java
Set<Long> relationIds = pathFinder.findAllShortestPathRelationIds(
    Set.copyOf(objectIds), allRelations, allFields);
relations = allRelations.stream()
    .filter(relation -> relationIds.contains(relation.getRelationId()))
    .toList();
```

将请求对象和关系两端对象加入 `includedObjectIds`。不再调用 `selectRelationsWithinObjects`。

- [ ] **步骤 4：运行查询与 Controller 集成测试**

运行：

```bash
TESTCONTAINERS_RYUK_DISABLED=true DOCKER_AUTH_CONFIG='{}' \
  mvn -Dtest=MetadataQueryServiceIntegrationTest,MetadataControllerIntegrationTest test
```

预期：全部 PASS。

- [ ] **步骤 5：提交**

```bash
git add src/main/java/com/example/dmi/metadata/application/MetadataQueryService.java \
  src/test/java/com/example/dmi/metadata/application/MetadataQueryServiceIntegrationTest.java \
  src/test/java/com/example/dmi/metadata/api/MetadataControllerIntegrationTest.java
git commit -m "feat: return shortest paths from metadata graph"
```

### 任务 3：移除数据库外键并提供重建脚本

**文件：**
- 修改：`src/main/resources/db/migration/V1__create_metadata_tables.sql`
- 创建：`scripts/rebuild-metadata-tables-without-foreign-keys.sql`
- 修改：`src/test/java/com/example/dmi/metadata/persistence/MetadataMapperIntegrationTest.java`
- 修改：`README.md`

- [ ] **步骤 1：编写失败的无外键集成测试**

在 Mapper 集成测试中查询：

```sql
SELECT COUNT(*)
FROM information_schema.REFERENTIAL_CONSTRAINTS
WHERE CONSTRAINT_SCHEMA = DATABASE()
```

断言结果为 `0`。使用 Spring `JdbcTemplate` 执行查询。

- [ ] **步骤 2：运行测试并确认失败**

运行：

```bash
TESTCONTAINERS_RYUK_DISABLED=true DOCKER_AUTH_CONFIG='{}' \
  mvn -Dtest=MetadataMapperIntegrationTest test
```

预期：FAIL，当前存在 5 个外键。

- [ ] **步骤 3：修改初始建表脚本**

删除全部 `FOREIGN KEY` 约束，保留：

- 对象名称唯一约束。
- 对象内字段名唯一约束。
- 关系组合唯一约束。
- `parent_object_id`、`object_id`、目标对象和目标字段普通索引。

为三张表及全部字段添加中文 `COMMENT`。

- [ ] **步骤 4：创建一次性重建 SQL**

脚本依次执行：

```sql
CREATE TABLE object_definition_backup AS SELECT * FROM object_definition;
CREATE TABLE object_field_backup AS SELECT * FROM object_field;
CREATE TABLE field_relation_backup AS SELECT * FROM field_relation;
DROP TABLE field_relation;
DROP TABLE object_field;
DROP TABLE object_definition;
```

随后复制新的无外键建表语句，按对象、字段、关系顺序恢复数据并删除备份表。脚本顶部注明停止写入与先备份要求。

- [ ] **步骤 5：记录重建方式并运行测试**

在 README 添加：

```bash
mysql -u dmi -p dmi < scripts/rebuild-metadata-tables-without-foreign-keys.sql
```

运行：

```bash
TESTCONTAINERS_RYUK_DISABLED=true DOCKER_AUTH_CONFIG='{}' \
  mvn -Dtest=MetadataMapperIntegrationTest,MetadataSaveServiceIntegrationTest test
```

预期：全部 PASS。

- [ ] **步骤 6：提交**

```bash
git add src/main/resources/db/migration/V1__create_metadata_tables.sql \
  scripts/rebuild-metadata-tables-without-foreign-keys.sql \
  src/test/java/com/example/dmi/metadata/persistence/MetadataMapperIntegrationTest.java README.md
git commit -m "feat: remove metadata database foreign keys"
```

### 任务 4：添加公共代码中文注释

**文件：**
- 修改：`src/main/java/com/example/dmi/metadata/api/MetadataController.java`
- 修改：`src/main/java/com/example/dmi/metadata/api/dto/*.java`
- 修改：`src/main/java/com/example/dmi/metadata/persistence/entity/*.java`
- 修改：`src/main/java/com/example/dmi/metadata/application/MetadataGraphPathFinder.java`
- 修改：`src/main/java/com/example/dmi/metadata/application/MetadataQueryService.java`
- 修改：`src/main/java/com/example/dmi/metadata/application/MetadataSaveService.java`

- [ ] **步骤 1：添加类型和字段 JavaDoc**

为 Controller、DTO 和实体添加中文 JavaDoc。DTO record 字段使用 `@param` 说明，例如：

```java
/**
 * 元数据字段响应。
 *
 * @param fieldId 字段全局唯一 ID
 * @param objectId 字段所属对象 ID
 * @param fieldName 字段名称
 */
public record FieldResponse(...) {}
```

- [ ] **步骤 2：添加核心方法和算法注释**

为保存、查询、路径查找公共方法添加中文 JavaDoc；只在 BFS 回溯等非直观代码块前添加简短中文注释，不为简单赋值和 getter/setter 添加注释。

- [ ] **步骤 3：编译并检查注释不影响代码**

运行：

```bash
mvn -DskipTests compile
git diff --check
```

预期：BUILD SUCCESS，且无空白错误。

- [ ] **步骤 4：提交**

```bash
git add src/main/java/com/example/dmi/metadata
git commit -m "docs: add metadata code comments"
```

### 任务 5：完整验证

**文件：**
- 修改：`scripts/verify-api.sh`
- 修改：`README.md`

- [ ] **步骤 1：扩展真实接口验证脚本**

在脚本中创建系列对象，并验证品牌与系列查询：

```bash
curl -fsS "$BASE_URL/api/metadata/graph?objectIds=$brand_id,$series_id" |
  jq -e '.objects | length == 3' >/dev/null
curl -fsS "$BASE_URL/api/metadata/graph?objectIds=$brand_id,$series_id" |
  jq -e '.relations | length == 2' >/dev/null
```

- [ ] **步骤 2：更新 README 查询说明**

明确多个 `objectIds` 返回每对对象之间所有最短路径的并集，并说明遍历忽略关系方向。

- [ ] **步骤 3：运行完整自动化测试**

运行：

```bash
TESTCONTAINERS_RYUK_DISABLED=true DOCKER_AUTH_CONFIG='{}' mvn clean test
```

预期：全部 PASS。

- [ ] **步骤 4：运行静态检查**

运行：

```bash
git diff --check
git status --short
```

预期：无空白错误；只有本任务预期文件变更。保留用户已修改的 `src/main/resources/application.yml`，不得覆盖。

- [ ] **步骤 5：提交**

```bash
git add scripts/verify-api.sh README.md
git commit -m "docs: verify shortest metadata paths"
```

