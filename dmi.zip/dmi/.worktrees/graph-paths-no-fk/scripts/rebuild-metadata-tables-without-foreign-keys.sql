-- 重建元数据表并移除数据库外键。
-- 执行前必须停止所有应用写入，并先完成数据库备份。
-- MySQL DDL 会隐式提交事务；如脚本中断，请先检查 backup 表再恢复服务。

-- 1. 备份当前三张元数据表。若 backup 表已存在，脚本会失败，避免覆盖已有备份。
CREATE TABLE object_definition_backup AS
SELECT * FROM object_definition;

CREATE TABLE object_field_backup AS
SELECT * FROM object_field;

CREATE TABLE field_relation_backup AS
SELECT * FROM field_relation;

-- 2. 删除原表。按关系、字段、对象顺序删除，避免旧外键阻止 DROP。
DROP TABLE field_relation;
DROP TABLE object_field;
DROP TABLE object_definition;

-- 3. 使用无外键版本重新创建对象定义表。
CREATE TABLE object_definition (
    object_id BIGINT NOT NULL COMMENT '对象ID',
    object_name VARCHAR(128) NOT NULL COMMENT '对象名称',
    parent_object_id BIGINT NULL COMMENT '父对象ID',
    description VARCHAR(512) NULL COMMENT '对象描述',
    created_at DATETIME(6) NOT NULL COMMENT '创建时间',
    updated_at DATETIME(6) NOT NULL COMMENT '更新时间',
    PRIMARY KEY (object_id),
    CONSTRAINT uk_object_definition_name UNIQUE (object_name),
    INDEX idx_object_definition_parent_object_id (parent_object_id)
) COMMENT='元数据对象定义表';

-- 4. 使用无外键版本重新创建对象字段表。
CREATE TABLE object_field (
    field_id BIGINT NOT NULL COMMENT '字段ID',
    object_id BIGINT NOT NULL COMMENT '所属对象ID',
    field_name VARCHAR(128) NOT NULL COMMENT '字段名称',
    field_type VARCHAR(32) NOT NULL COMMENT '字段类型',
    is_primary_key BOOLEAN NOT NULL COMMENT '是否主键字段',
    description VARCHAR(512) NULL COMMENT '字段描述',
    created_at DATETIME(6) NOT NULL COMMENT '创建时间',
    updated_at DATETIME(6) NOT NULL COMMENT '更新时间',
    PRIMARY KEY (field_id),
    CONSTRAINT uk_object_field_name UNIQUE (object_id, field_name),
    INDEX idx_object_field_object_id (object_id)
) COMMENT='元数据对象字段表';

-- 5. 使用无外键版本重新创建字段关系表。
CREATE TABLE field_relation (
    relation_id BIGINT NOT NULL COMMENT '关系ID',
    relation_name VARCHAR(128) NULL COMMENT '关系名称',
    source_field_id BIGINT NOT NULL COMMENT '源字段ID',
    target_object_id BIGINT NOT NULL COMMENT '目标对象ID',
    target_field_id BIGINT NOT NULL COMMENT '目标字段ID',
    relation_type VARCHAR(32) NOT NULL COMMENT '关系类型',
    description VARCHAR(512) NULL COMMENT '关系描述',
    created_at DATETIME(6) NOT NULL COMMENT '创建时间',
    updated_at DATETIME(6) NOT NULL COMMENT '更新时间',
    PRIMARY KEY (relation_id),
    CONSTRAINT uk_field_relation UNIQUE (source_field_id, target_field_id, relation_type),
    INDEX idx_relation_source_field_id (source_field_id),
    INDEX idx_relation_target_object_id (target_object_id),
    INDEX idx_relation_target_field_id (target_field_id)
) COMMENT='元数据字段关系表';

-- 6. 按对象、字段、关系顺序恢复数据。
INSERT INTO object_definition (
    object_id,
    object_name,
    parent_object_id,
    description,
    created_at,
    updated_at
)
SELECT
    object_id,
    object_name,
    parent_object_id,
    description,
    created_at,
    updated_at
FROM object_definition_backup;

INSERT INTO object_field (
    field_id,
    object_id,
    field_name,
    field_type,
    is_primary_key,
    description,
    created_at,
    updated_at
)
SELECT
    field_id,
    object_id,
    field_name,
    field_type,
    is_primary_key,
    description,
    created_at,
    updated_at
FROM object_field_backup;

INSERT INTO field_relation (
    relation_id,
    relation_name,
    source_field_id,
    target_object_id,
    target_field_id,
    relation_type,
    description,
    created_at,
    updated_at
)
SELECT
    relation_id,
    relation_name,
    source_field_id,
    target_object_id,
    target_field_id,
    relation_type,
    description,
    created_at,
    updated_at
FROM field_relation_backup;

-- 7. 恢复完成后删除临时备份表。
DROP TABLE field_relation_backup;
DROP TABLE object_field_backup;
DROP TABLE object_definition_backup;
