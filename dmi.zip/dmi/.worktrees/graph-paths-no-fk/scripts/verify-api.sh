#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:8080}"
RUN_ID="${RUN_ID:-$(date +%s)}"
brand_name="验证品牌-$RUN_ID"
product_name="验证产品-$RUN_ID"
series_name="验证系列-$RUN_ID"
error_response_file=$(mktemp "${TMPDIR:-/tmp}/dmi-field-reference-error.XXXXXX.json")
trap 'rm -f "$error_response_file"' EXIT

brand_response=$(curl -fsS -X POST "$BASE_URL/api/metadata/objects/save" \
  -H 'Content-Type: application/json' \
  -d "$(jq -cn --arg objectName "$brand_name" '{
    objectName: $objectName,
    fields: [
      {fieldName: "id", fieldType: "STRING", primaryKey: true},
      {fieldName: "name", fieldType: "STRING", primaryKey: false}
    ],
    outgoingRelations: []
  }')")
brand_id=$(jq -er '.objectId' <<<"$brand_response")
brand_field_id=$(curl -fsS "$BASE_URL/api/metadata/objects/$brand_id" | jq -er '.fields[] | select(.fieldName == "id") | .fieldId')

product_response=$(curl -fsS -X POST "$BASE_URL/api/metadata/objects/save" \
  -H 'Content-Type: application/json' \
  -d "$(jq -cn --arg objectName "$product_name" --argjson brandId "$brand_id" --argjson brandFieldId "$brand_field_id" '{
    objectName: $objectName,
    fields: [
      {fieldName: "id", fieldType: "STRING", primaryKey: true},
      {fieldName: "brand_id", fieldType: "STRING", primaryKey: false}
    ],
    outgoingRelations: [
      {
        relationName: "所属品牌",
        sourceFieldName: "brand_id",
        targetObjectId: $brandId,
        targetFieldId: $brandFieldId,
        relationType: "MANY_TO_ONE"
      }
    ]
  }')")
product_id=$(jq -er '.objectId' <<<"$product_response")
product_field_id=$(curl -fsS "$BASE_URL/api/metadata/objects/$product_id" | jq -er '.fields[] | select(.fieldName == "id") | .fieldId')

series_response=$(curl -fsS -X POST "$BASE_URL/api/metadata/objects/save" \
  -H 'Content-Type: application/json' \
  -d "$(jq -cn --arg objectName "$series_name" --argjson productId "$product_id" --argjson productFieldId "$product_field_id" '{
    objectName: $objectName,
    fields: [
      {fieldName: "id", fieldType: "STRING", primaryKey: true},
      {fieldName: "series_name", fieldType: "STRING", primaryKey: false},
      {fieldName: "product_id", fieldType: "STRING", primaryKey: false}
    ],
    outgoingRelations: [
      {
        relationName: "所属产品",
        sourceFieldName: "product_id",
        targetObjectId: $productId,
        targetFieldId: $productFieldId,
        relationType: "MANY_TO_ONE"
      }
    ]
  }')")
series_id=$(jq -er '.objectId' <<<"$series_response")

curl -fsS "$BASE_URL/api/metadata/objects/$product_id" | jq -e '.outgoingRelations | length == 1' >/dev/null
curl -fsS "$BASE_URL/api/metadata/objects/$series_id" | jq -e '.outgoingRelations | length == 1' >/dev/null
curl -fsS "$BASE_URL/api/metadata/graph?objectIds=$brand_id" | jq -e '.objects | length == 2' >/dev/null
curl -fsS "$BASE_URL/api/metadata/graph?objectIds=$brand_id,$product_id" | jq -e '.relations | length == 1' >/dev/null
graph_response=$(curl -fsS "$BASE_URL/api/metadata/graph?objectIds=$brand_id,$series_id")
jq -e '.objects | length == 3' <<<"$graph_response" >/dev/null
jq -e '.relations | length == 2' <<<"$graph_response" >/dev/null
jq -e --arg brand_name "$brand_name" --arg product_name "$product_name" --arg series_name "$series_name" \
  '([.objects[].objectName] | index($brand_name) and index($product_name) and index($series_name))' \
  <<<"$graph_response" >/dev/null

brand_name_field_id=$(curl -fsS "$BASE_URL/api/metadata/objects/$brand_id" |
  jq -er '.fields[] | select(.fieldName == "name") | .fieldId')
status=$(curl -sS -o "$error_response_file" -w '%{http_code}' -X POST \
  "$BASE_URL/api/metadata/objects/save" -H 'Content-Type: application/json' \
  -d "$(jq -cn --argjson objectId "$brand_id" --arg objectName "$brand_name" --argjson fieldId "$brand_name_field_id" '{
    objectId: $objectId,
    objectName: $objectName,
    fields: [
      {fieldId: $fieldId, fieldName: "name", fieldType: "STRING", primaryKey: true}
    ],
    outgoingRelations: []
  }')")
test "$status" = "409"
jq -e '.code == "FIELD_REFERENCED"' "$error_response_file" >/dev/null

echo "Metadata API verification passed: brand=$brand_id product=$product_id series=$series_id"
